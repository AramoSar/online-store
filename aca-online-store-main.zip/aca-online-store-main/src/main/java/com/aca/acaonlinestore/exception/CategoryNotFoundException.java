package com.aca.acaonlinestore.exception;

import com.aca.acaonlinestore.entity.Category;

public class CategoryNotFoundException extends Exception{
    public CategoryNotFoundException(String str){
        super(str);
    }
    public CategoryNotFoundException(String str, Throwable throwable){
        super(str,throwable);
    }
}
