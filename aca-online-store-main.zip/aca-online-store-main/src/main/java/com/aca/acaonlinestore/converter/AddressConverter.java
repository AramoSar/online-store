package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.model.AddressDTO;
import org.springframework.stereotype.Component;

@Component
public class AddressConverter implements Converter<AddressDTO, Address>{
    @Override
    public Address convertToEntity(AddressDTO model, Address entity) {
        entity.setCity(model.getCity());
        entity.setStreet(model.getStreet());
        entity.setCountry(model.getCountry());
        entity.setPostalCode(model.getPostalCode());
        return entity;
    }

    @Override
    public AddressDTO convertToModel(Address entity, AddressDTO model) {
        model.setId(entity.getId());
        model.setPostalCode(entity.getPostalCode());
        model.setCity(entity.getCity());
        model.setStreet(entity.getStreet());
        model.setCountry(entity.getCountry());
        return model;
    }
}
