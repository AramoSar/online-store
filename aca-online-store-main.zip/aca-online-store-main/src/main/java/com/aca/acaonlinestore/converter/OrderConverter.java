package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.Order;
import com.aca.acaonlinestore.entity.OrderProduct;
import com.aca.acaonlinestore.entity.StatusHistory;
import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.OrderDTO;
import com.aca.acaonlinestore.model.OrderProductDTO;
import com.aca.acaonlinestore.model.*;
import com.aca.acaonlinestore.model.courier.OrderCourierRequestJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class OrderConverter implements Converter<OrderDTO, Order> {
    private final OrderProductConverter orderProductConverter;
    private final AddressConverter addressConverter;
    private final StatusHistoryConverter statusHistoryConverter;

    @Autowired
    public OrderConverter(OrderProductConverter orderProductConverter, AddressConverter addressConverter, StatusHistoryConverter statusHistoryConverter) {
        this.orderProductConverter = orderProductConverter;
        this.addressConverter = addressConverter;
        this.statusHistoryConverter = statusHistoryConverter;
    }

    @Override
    public Order convertToEntity(OrderDTO model, Order entity) {
        List<OrderProduct> orderProductList = model.getOrderProductList()
                .stream()
                .map(orderProductDTO -> orderProductConverter.convertToEntity(orderProductDTO, new OrderProduct()))
                .collect(Collectors.toList());
        entity.setOrderProduct(orderProductList);

        Address address = addressConverter.convertToEntity(model.getAddress(), new Address());
        entity.setDeliveryPrice(model.getDeliveryPrice());
        entity.setSize(model.getSize());
        entity.setAddress(address);
        entity.setTotalPrice(model.getTotalPrice());
        entity.setStatus(model.getStatus());
        List<StatusHistoryDTO> statusHistories = model.getStatusHistories();
        List<StatusHistory> statusHistoryList = new ArrayList<>();
        for (StatusHistoryDTO statusHistoryDTO : statusHistories) {
            StatusHistory currentStatusHistory = statusHistoryConverter.convertToEntity(statusHistoryDTO, new StatusHistory());
            statusHistoryList.add(currentStatusHistory);
        }
        entity.setStatusHistory(statusHistoryList);
        entity.setDate(model.getDate());
        entity.setTrackingId(model.getTrackingId());
        return entity;
    }

    @Override
    public OrderDTO convertToModel(Order entity, OrderDTO model) {
        model.setId(entity.getId());
        AddressDTO addressDTO = addressConverter.convertToModel(entity.getAddress(), new AddressDTO());
        model.setAddress(addressDTO);
        model.setStatus(entity.getStatus());
        model.setTotalPrice(entity.getTotalPrice());

        List<OrderProductDTO> orderProductDTOList = entity.getOrderProduct()
                .stream()
                .map(orderProduct -> orderProductConverter.convertToModel(orderProduct, new OrderProductDTO()))
                .collect(Collectors.toList());
        model.setOrderProductList(orderProductDTOList);

        List<StatusHistoryDTO> statusHistoryDTOList = entity.getStatusHistory()
                .stream()
                .map(statusHistory -> statusHistoryConverter.convertToModel(statusHistory, new StatusHistoryDTO()))
                .collect(Collectors.toList());
        model.setStatusHistories(statusHistoryDTOList);

        model.setDate(entity.getDate());
        model.setTrackingId(entity.getTrackingId());
        model.setSize(entity.getSize());
        model.setDeliveryPrice(entity.getDeliveryPrice());
        model.setTotalWeight(entity.getTotalWeight());
        return model;
    }

    public OrderCourierRequestJson convertToCourierJson(Order entity, OrderCourierRequestJson model) {
        model.setCountry(entity.getAddress().getCountry());
        model.setCity(entity.getAddress().getCity());
        model.setOrderId(entity.getId());
        model.setFullName(entity.getUser().getUsername());
        model.setPhone(entity.getUser().getPhoneNumber());
        model.setZipCode(entity.getAddress().getPostalCode());
        model.setAddress(entity.getAddress().getStreet());
        model.setDeliveryPrice(entity.getDeliveryPrice());
        model.setSize(entity.getSize());
        model.setWeightKg(entity.getTotalWeight());
        model.setTotalPrice(entity.getTotalPrice());
        return model;
    }
}
