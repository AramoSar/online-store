package com.aca.acaonlinestore.model;

import com.aca.acaonlinestore.entity.Status;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class StatusHistoryDTO {
    private long id;
    private Status statusFrom;
    private Status statusTo;
    private Date dateOfChange;
    private String reason;
}

