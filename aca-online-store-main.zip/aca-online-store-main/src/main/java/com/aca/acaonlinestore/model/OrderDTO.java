package com.aca.acaonlinestore.model;

import com.aca.acaonlinestore.entity.*;
import com.aca.acaonlinestore.model.courier.OrderCourierRequestJson;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class OrderDTO {
    private long id;
    @NotNull(message = "Order can not be empty")
    private List<OrderProductDTO> orderProductList;
    private double totalPrice;
    @NotNull(message = "Address cna not be null")
    private AddressDTO address;
    @NotNull(message = "Date can not be null")
    private Date date;
    @NotNull(message = "Status can not be null")
    private Status status;
    private double deliveryPrice;
    private double totalWeight;
    private OrderCourierRequestJson.Size size;
    private String trackingId;
    private List<StatusHistoryDTO> statusHistories;

}
