package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.AddressConverter;
import com.aca.acaonlinestore.converter.UserConverter;
import com.aca.acaonlinestore.converter.UserResponseConverter;
import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.Cart;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.exception.UserNotFoundException;
import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.UserDTO;
import com.aca.acaonlinestore.model.UserResponseJson;
import com.aca.acaonlinestore.repository.AddressRepository;
import com.aca.acaonlinestore.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Slf4j
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;
    private final UserConverter userConverter;
    private final UserResponseConverter userResponseConverter;
    private final AddressRepository addressRepository;
    private final AddressConverter addressConverter;
    private final PasswordEncoder passwordEncoder;
    @Autowired
    public UserService(UserRepository userRepository, AddressRepository addressRepository, UserConverter userConverter, UserResponseConverter userResponseConverter, AddressConverter addressConverter, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.addressRepository = addressRepository;
        this.userConverter = userConverter;
        this.userResponseConverter = userResponseConverter;
        this.addressConverter = addressConverter;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User with email " + email + " not found!!!"));
        GrantedAuthority authority = new SimpleGrantedAuthority(user.getRole().name());
        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), Arrays.asList(authority));
    }

    public User getUserByEmail(String email) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with this credentials");
        }
        return optionalUser.get();
    }

    public User getUserById (long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            throw new UserNotFoundException("User not found with this id");
        }
        return optionalUser.get();
    }
    public UserResponseJson getUserInfo(String email) {
        User user = getUserByEmail(email);
        return userResponseConverter.convertToModel(user, new UserResponseJson());
    }

    public Boolean userExists(String username, String email) {
        return userRepository.existsByUsername(username) || userRepository.existsByEmail(email);
    }

    /**
     * Method for getting an authenticated user.
     * Can be used for checking the logged-in user
     *
     * @return      UserDetails which contains username, password, authority(role) of logged-in user
     * */
    public UserDetails getAuthUserPrincipal() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return (UserDetails)auth.getPrincipal();
    }

    @Transactional
    public User saveUser (UserDTO model, String password, User.Role role) {
        User user = new User();
        Cart cart = new Cart();
        List<Address> addresses = new ArrayList<>();
        user.setDeliverAddress(addresses);
        user.setCart(cart);
        user.setRole(role);
        userConverter.convertToEntity(model, user);
        user.setPassword(password);
        log.info("User converted and ready to be saved", user);
        return userRepository.save(user);
    }

    @Transactional
    public User updateUser (String email, UserDTO model) {
        User user = getUserByEmail(email);
        userConverter.convertAndValidateToEntity(model, user);
        if (model.getPassword() != null) {
            user.setPassword(passwordEncoder.encode(model.getPassword()));
        }
        return userRepository.save(user);
    }

    @Transactional
    public boolean deleteUser (String email) {
        User user = getUserByEmail(email);
        userRepository.delete(user);
        return !userRepository.existsByEmail(email);
    }

    @Transactional
    public User addAddress(String email, AddressDTO addressDTO) {
        User user = getUserByEmail(email);
        Address address = addressConverter.convertToEntity(addressDTO, new Address());
        address.setUser(user);
        addressRepository.save(address);
        return userRepository.save(user);
    }

    @Transactional
    public Address getAddressById(String email, long addressId) {
        User user = getUserByEmail(email);
        return user.getDeliverAddress().stream().filter(a -> a.getId() == addressId).toList().get(0);
    }

    @Transactional
    public void updateUserAddress(String email, long addressId, AddressDTO addressDTO) {
        User user = getUserByEmail(email);
        Address address = user.getDeliverAddress().stream().filter(a -> a.getId() == addressId).toList().get(0);
        addressConverter.convertToEntity(addressDTO, address);
        userRepository.save(user);
    }

    @Transactional
    public User deleteAddress(String email, long addressId) {
        User user = getUserByEmail(email);
        Address address = addressRepository.findById(addressId).get();
        address.setUser(null);
        addressRepository.delete(address);
        user.getDeliverAddress().removeIf(a -> a.getId() == addressId);
        return userRepository.save(user);
    }

    @Transactional
    public List<AddressDTO> getAllAddresses(String email) {
        User user = getUserByEmail(email);
        List<AddressDTO> addressDTOList = new ArrayList<>();
        for (Address deliverAddress : user.getDeliverAddress()) {
            AddressDTO currentAddressDTO = addressConverter.convertToModel(deliverAddress, new AddressDTO());
            addressDTOList.add(currentAddressDTO);
        }
        return addressDTOList;
    }
}