package com.aca.acaonlinestore.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OrderProductDTO {
    private long id;
    private int quantity;
    private ProductDTO productDto;
}
