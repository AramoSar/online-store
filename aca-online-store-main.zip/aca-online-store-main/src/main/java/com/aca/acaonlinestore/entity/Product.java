package com.aca.acaonlinestore.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "price", nullable = false)
    private double price;

    @Column(name = "availability", nullable = false)
    private int availability;

    @Column(name = "averageRate")
    private double averageRate;

    @Column(name = "weightKg")
    private double weightKg;

    @ManyToOne
    @JoinColumn(name = "store_id")
    private Store store;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    @OneToMany(mappedBy = "ratedProduct")
    private List<ProductRating> productRating;


    public Product(String some_product, String some_description, double v, int i, int i1, Store store, Category category, ArrayList<ProductRating> productRatings) {
    }
}
