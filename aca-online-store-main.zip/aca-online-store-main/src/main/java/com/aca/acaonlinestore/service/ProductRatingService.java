package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.ProductRatingConverter;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.ProductRating;
import com.aca.acaonlinestore.model.ProductRatingDTO;
import com.aca.acaonlinestore.repository.ProductRatingRepository;
import com.aca.acaonlinestore.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;

@Service
public class ProductRatingService {

    private final ProductRepository productRepository;
    private final ProductRatingConverter productRatingConverter;
    private final ProductRatingRepository productRatingRepository;

    @Autowired
    public ProductRatingService(ProductRepository productRepository, ProductRatingConverter productRatingConverter,
                                ProductRatingRepository productRatingRepository){
        this.productRepository = productRepository;
        this.productRatingConverter = productRatingConverter;
        this.productRatingRepository  = productRatingRepository;
    }

    @Transactional
    public double createMeanRate(long product_id){
        Optional<Product> opt = productRepository.findById(product_id);
        Product product = opt.orElse(null);
        assert product != null;
        List<ProductRating> allRates = product.getProductRating();
        int[] rates = new int[allRates.size()];
        double finalRate = 0;
        for( int i = 0; i< allRates.size(); i++){
            rates[i] = allRates.get(i).getRate();
            finalRate += rates[i];
        }
        finalRate = finalRate/rates.length;
        BigDecimal roundedRate = BigDecimal.valueOf(finalRate).setScale(2, RoundingMode.HALF_UP);
        product.setAverageRate(roundedRate.doubleValue());
        productRepository.save(product);
        return roundedRate.doubleValue();
    }

    @Transactional
    public ProductRatingDTO createProductRating(ProductRatingDTO model){
        ProductRating productRating = new ProductRating();
        productRating = productRatingConverter.convertToEntity(model,productRating);
        productRatingRepository.save(productRating);
        return productRatingConverter.convertToModel(productRating,model);
    }

}
