package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.OrderProduct;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.model.OrderProductDTO;
import com.aca.acaonlinestore.model.ProductDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrderProductConverter implements Converter<OrderProductDTO, OrderProduct> {
    private final ProductConverter productConverter;

    @Autowired
    public OrderProductConverter(ProductConverter productConverter) {
        this.productConverter = productConverter;
    }

    @Override
    public OrderProduct convertToEntity(OrderProductDTO model, OrderProduct entity) {
        Product product = productConverter.convertToEntity(model.getProductDto(), new Product());
        entity.setProduct(product);
        entity.setQuantity(model.getQuantity());
        return entity;
    }

    @Override
    public OrderProductDTO convertToModel(OrderProduct entity, OrderProductDTO model) {
        ProductDTO productDto = productConverter.convertToModel(entity.getProduct(), new ProductDTO());
        model.setId(entity.getId());
        model.setQuantity(entity.getQuantity());
        model.setProductDto(productDto);
        return model;
    }
}
