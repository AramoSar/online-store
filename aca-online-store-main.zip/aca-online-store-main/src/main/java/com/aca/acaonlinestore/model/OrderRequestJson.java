package com.aca.acaonlinestore.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderRequestJson {
    private long addressId;
    private long productId;
    private int quantity;
}
