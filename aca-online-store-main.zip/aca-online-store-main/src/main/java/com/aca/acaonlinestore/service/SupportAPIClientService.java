package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.model.ticket.TicketRequestJson;
import com.aca.acaonlinestore.model.ticket.TicketResponseJson;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class SupportAPIClientService {
    private final static String SUPPORT_API_URL = "http://localhost:8282";
    private final static String apiKey = "6A7A9B93B54A48A589C9AB2A20834068";
    private final static String apiSecret = "58c1c0b9-0c03-4275-ada8-6af181b1fd17";

    public static TicketResponseJson createTicket(long userId, TicketRequestJson ticketRequestJson) throws URISyntaxException, IOException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();

        Map<String, Long> params = new HashMap<String, Long>();
        params.put("userId", userId);
        URI uri = UriComponentsBuilder.fromUriString(SUPPORT_API_URL + "/api/ticket/add")
                .buildAndExpand(params)
                .toUri();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .headers("Content-type", "application/json")
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(ticketRequestJson)))
                .build();


        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> httpResponse =
                httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        String body = httpResponse.body();
        log.info("Response body from creating ticket: " + body);

        TicketResponseJson ticketResponseJson = objectMapper.readValue(body, TicketResponseJson.class);

        return ticketResponseJson;
    }

    public static TicketResponseJson closeTicket(long userId) throws IOException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();

        Map<String, Long> params = new HashMap<>();
        params.put("userId", userId);

        URI uri = UriComponentsBuilder
                .fromUriString(SUPPORT_API_URL + "/api/ticket/close")
                .buildAndExpand(params)
                .toUri();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .headers("Content-type", "application/json")
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();

        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        String body = response.body();
        log.info("Response body from closing ticket: " + body);

        TicketResponseJson ticketResponseJson = objectMapper.readValue(body, TicketResponseJson.class);

        return ticketResponseJson;

    }


    public static TicketResponseJson sendMessage(long userId, TicketRequestJson ticketRequestJson) throws IOException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Long> params = new HashMap<>();
        params.put("userId", userId);

        URI uri = UriComponentsBuilder
                .fromUriString(SUPPORT_API_URL + "/api/ticket/sendMessage")
                .buildAndExpand(params)
                .toUri();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .headers("Content-type", "application/json")
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(ticketRequestJson)))
                .build();

        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String body = response.body();
        log.info("Response body from sendMessage method: " + body);

        TicketResponseJson ticketResponseJson = objectMapper.readValue(body, TicketResponseJson.class);

        return ticketResponseJson;

    }

    public static TicketResponseJson getMessage(long userId) throws IOException, InterruptedException {
        Map<String, Long> params = new HashMap<>();
        params.put("userId", userId);
        URI uri = UriComponentsBuilder
                .fromUriString(SUPPORT_API_URL + "/api/ticket/messages")
                .buildAndExpand(params)
                .toUri();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .headers("Content-type", "application/json")
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .GET().build();

        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String body = response.body();

        log.info("Response body of getting message: " + body);
        ObjectMapper objectMapper = new ObjectMapper();

        TicketResponseJson ticketResponseJson = objectMapper.readValue(body, TicketResponseJson.class);
        return ticketResponseJson;
    }
}
