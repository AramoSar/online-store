package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.CategoryConverter;
import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.model.CategoryDTO;
import com.aca.acaonlinestore.repository.CategoryRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriesService {

    CategoryRepository categoriesRepository;
    private final CategoryConverter categoryConverter;

    @Autowired
    public CategoriesService(CategoryRepository categoriesRepository, CategoryConverter categoryConverter) {
        this.categoriesRepository = categoriesRepository;
        this.categoryConverter = categoryConverter;
    }

    public Category getCategoryById(long id) {
        return categoriesRepository.findById(id).get();
    }

    public List<Category> getAllCategories() {
        return categoriesRepository.findAll();
    }

    @Transactional
    public Category save(CategoryDTO categoryDTO) {
        Category category = categoryConverter.convertToEntity(categoryDTO, new Category());
        return categoriesRepository.save(category);
    }

    @Transactional
    public Category update(long categoryId, CategoryDTO categoryDTO) {
        Category category = getCategoryById(categoryId);
        categoryConverter.convertToEntity(categoryDTO, category);
        return category;
    }

    @Transactional
    public void deleteCategory(long id) {
        categoriesRepository.deleteById(id);
    }
}
