package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.model.UserDTO;
import org.springframework.stereotype.Component;

@Component
public class UserConverter implements Converter<UserDTO, User>{
    @Override
    public User convertToEntity(UserDTO model, User entity) {
        entity.setPhoneNumber(model.getPhoneNumber());
        entity.setEmail(model.getEmail());
        entity.setPassword(model.getPassword());
        entity.setUsername(model.getUsername());
        return entity;
    }

    @Override
    public UserDTO convertToModel(User entity, UserDTO model) {
        model.setEmail(entity.getEmail());
        model.setUsername(entity.getUsername());
        model.setPassword(entity.getPassword());
        model.setPhoneNumber(entity.getPhoneNumber());
        return model;
    }

    public User convertAndValidateToEntity(UserDTO model, User entity) {
        if (model.getEmail() != null) {
            entity.setEmail(model.getEmail());
        }
        if (model.getPassword() != null) {
            entity.setPassword(model.getPassword());
        }
        if (model.getUsername() != null) {
            entity.setUsername(model.getUsername());
        }
        if (model.getPhoneNumber() != null) {
            entity.setPhoneNumber(model.getPhoneNumber());
        }
        return entity;
    }
}
