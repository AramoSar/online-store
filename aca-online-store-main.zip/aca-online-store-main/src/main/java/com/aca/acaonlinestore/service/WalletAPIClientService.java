package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.model.WalletValidationJson;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
public class WalletAPIClientService {
    public static final String WALLET_API_URL = "http://localhost:7074";
    public static final String apiKey = "7aK9B3pW";
    public static final String apiSecret = "xP2sR5vL";


    public static boolean validatePayment(String key) throws URISyntaxException, IOException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();
        WalletValidationJson walletValidationJson = new WalletValidationJson();
        walletValidationJson.setKey(key);
        walletValidationJson.setSiteName("Aca");
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(WALLET_API_URL + "/payment/validate"))
                .header("Content-type", "application/json;charset=UTF-8")
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(walletValidationJson)))
                .build();

        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String body = httpResponse.body();

        return objectMapper.readValue(body, Boolean.class );
    }
}
