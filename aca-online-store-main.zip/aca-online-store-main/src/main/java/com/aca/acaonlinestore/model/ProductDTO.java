package com.aca.acaonlinestore.model;

import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.entity.ProductRating;
import com.aca.acaonlinestore.entity.Store;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDTO {
    private long id;
    private String name;
    private String description;
    private double price;
    private int availability;
    private double averageRate;
    private double weightKg;
    private long storeId;
    private long categoryId;
    private String categoryName;


}
