package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.AddressConverter;
import com.aca.acaonlinestore.converter.StoreConverter;
import com.aca.acaonlinestore.converter.UserConverter;
import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.Store;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.model.StoreDTO;
import com.aca.acaonlinestore.model.UserDTO;
import com.aca.acaonlinestore.repository.AddressRepository;
import com.aca.acaonlinestore.repository.StoreRepository;
import com.aca.acaonlinestore.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StoreService {
    private final StoreRepository storeRepository;
    private final StoreConverter storeConverter;
    private final  UserService userService;
    private final UserConverter userConverter;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AddressRepository addressRepository;
    private final AddressConverter addressConverter;

    @Autowired
    public StoreService(StoreRepository storeRepository, StoreConverter storeConverter, UserService userService, UserConverter userConverter, UserRepository userRepository, PasswordEncoder passwordEncoder, AddressRepository addressRepository, AddressConverter addressConverter) {
        this.storeRepository = storeRepository;
        this.storeConverter = storeConverter;
        this.userService = userService;
        this.userConverter = userConverter;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.addressRepository = addressRepository;
        this.addressConverter = addressConverter;
    }


    @Transactional
    public StoreDTO registerStore(StoreDTO storeDto, UserDTO storeAdmin){
        Address address = addressConverter.convertToEntity(storeDto.getAddressDTO(), new Address());
        addressRepository.save(address);
        Store store = storeConverter.convertToEntity(storeDto, new Store());
        store.setAddress(address);
        Store registeredStore = storeRepository.save(store);
        User user = userService.saveUser(storeAdmin, passwordEncoder.encode(storeAdmin.getPassword()), User.Role.ROLE_STORE_ADMIN);
        user.setStore(registeredStore);
        userRepository.save(user);
        return storeConverter.convertToModel(registeredStore,new StoreDTO());
    }

    @Transactional
    public List<StoreDTO> getAllStores(){
        List<Store> entityList = storeRepository.findAll();
        return entityList.stream().map(store->storeConverter.convertToModel(store,new StoreDTO())).collect(Collectors.toList());
    }


    @Transactional
    public Double getRate(long store_id){
        Optional<Store> opt = storeRepository.findById(store_id);
        Store store = opt.orElse(null);
        assert store != null;
        List<Product> products = store.getProducts().stream().toList();
        if (products.isEmpty()){
            System.out.println("Empty store with no products");
            store.setRating(1);
            storeRepository.save(store);
            return store.getRating();
        }else{
            double means = products.stream().mapToDouble(Product::getAverageRate).sum();
            double rate = means/products.size();
            BigDecimal roundedRate = BigDecimal.valueOf(rate).setScale(2, RoundingMode.HALF_UP);
            store.setRating(roundedRate.doubleValue());
            storeRepository.save(store);
            return  roundedRate.doubleValue();
        }

    }

    @Transactional
    public StoreDTO getStoreById(long storeId){
        Optional<Store> storeOptional = storeRepository.findById(storeId);
        if (storeOptional.isEmpty()) {
            throw new NoSuchElementException();
        } else {
            Store store = storeOptional.get();
            return storeConverter.convertToModel(store, new StoreDTO());
        }
    }

    @Transactional
    public StoreDTO updateStore(long storeId, StoreDTO storeDto){
        Optional<Store> storeOptional = storeRepository.findById(storeId);
        if (storeOptional.isEmpty()){
            throw new NoSuchElementException();
        }
        Store store = storeOptional.get();
        store.setName(storeDto.getName());
        store.setDescription(storeDto.getDescription());
        store.setRating(storeDto.getRating());
        storeRepository.save(store);
        return storeConverter.convertToModel(store,new StoreDTO());
    }

    @Transactional
    public void deleteStoreById(long storeId,long adminId){
        storeRepository.deleteById(storeId);
        userRepository.deleteById(adminId);
    }

    @Transactional
    public StoreDTO getMyStore(){
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        UserDetails principal = (UserDetails)auth.getPrincipal();
        User userByUsernameOrEmail = userService.getUserByEmail(principal.getUsername());
        Store store = userByUsernameOrEmail.getStore();
        return storeConverter.convertToModel(store,new StoreDTO());
    }
}
