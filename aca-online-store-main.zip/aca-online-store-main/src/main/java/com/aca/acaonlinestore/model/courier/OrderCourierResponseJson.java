package com.aca.acaonlinestore.model.courier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderCourierResponseJson {
    private String status;
    private String trackingNumber;
}

/*
* {
    "status": "Created order",
    "trackingNumber": "7b386293-ce8a-4c8a-ad97-98f1c97c9040"
   }
* */
