package com.aca.acaonlinestore.model;

import lombok.Data;

import java.util.List;

@Data
public class UserResponseJson {
    private long id;
    private String username;
    private String email;
    private String phoneNumber;
    private List<AddressDTO> address;
}
