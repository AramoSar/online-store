package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.Store;
import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.StoreDTO;
import com.aca.acaonlinestore.repository.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.NoSuchElementException;
import java.util.Optional;

@Component
public class StoreConverter implements Converter<StoreDTO,Store>{
    private final AddressConverter addressConverter;

    @Autowired
    public StoreConverter(AddressConverter addressConverter) {
        this.addressConverter = addressConverter;
    }

    @Override
    public Store convertToEntity(StoreDTO model, Store entity) {
        entity.setName(model.getName());
        entity.setRating(model.getRating());
        entity.setDescription(model.getDescription());
        return entity;
    }

    @Override
    public StoreDTO convertToModel(Store entity, StoreDTO model) {
        model.setId(entity.getId());
        model.setName(entity.getName());
        model.setDescription(entity.getDescription());
        model.setRating(entity.getRating());
        model.setAddressDTO(addressConverter.convertToModel(entity.getAddress(),new AddressDTO()));
        return model;
    }


}
