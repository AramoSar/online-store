package com.aca.acaonlinestore.model;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressDTO {
    private long id;

    @NotEmpty(message = "Field can't be empty")
    private String city;

    @NotEmpty(message = "Field can't be empty")
    private String country;

    @NotEmpty(message = "Field can't be empty")
    private String street;

    @NotEmpty(message = "Field can't be empty")
    private String postalCode;
}
