package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.converter.CartConverter;
import com.aca.acaonlinestore.entity.Cart;
import com.aca.acaonlinestore.exception.ProductNotFoundException;
import com.aca.acaonlinestore.model.CartDTO;
import com.aca.acaonlinestore.model.CartRequestJson;
import com.aca.acaonlinestore.service.CartService;
import com.aca.acaonlinestore.service.UserService;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartRestController {
    private final CartService cartService;
    private final UserService userService;
    private CartConverter cartConverter;

    @Autowired
    public CartRestController(CartService cartService, UserService userService, CartConverter cartConverter) {
        this.cartService = cartService;
        this.userService = userService;
        this.cartConverter = cartConverter;
    }

    @RolesAllowed("USER")
    @GetMapping()
    public CartDTO viewCart() {
        UserDetails principal = userService.getAuthUserPrincipal();
        Cart cart = cartService.viewCart(principal.getUsername());
        return cartConverter.convertToModel(cart, new CartDTO());
    }


    @RolesAllowed("USER")
    @PutMapping ( "/add" )
    public CartDTO addToCart(@RequestBody CartRequestJson cartRequestJson) throws ProductNotFoundException {
        UserDetails principal = userService.getAuthUserPrincipal();

        Cart cart = cartService.addToCart(principal.getUsername(), cartRequestJson);

        return cartConverter.convertToModel(cart, new CartDTO());
    }

    @RolesAllowed("USER")
    @PutMapping("/remove/{productId}")
    public CartDTO removeFromCart(@PathVariable long productId) {
        UserDetails principal = userService.getAuthUserPrincipal();

        Cart cart = cartService.removeFromCart(principal.getUsername(), productId);

        return cartConverter.convertToModel(cart, new CartDTO());
    }

    @RolesAllowed("USER")
    @PutMapping("/empty")
    public double emptyCart() {
        UserDetails principal = userService.getAuthUserPrincipal();

        Cart cart = cartService.emptyCart(principal.getUsername());

        return cart.getSubtotal();
    }



}
