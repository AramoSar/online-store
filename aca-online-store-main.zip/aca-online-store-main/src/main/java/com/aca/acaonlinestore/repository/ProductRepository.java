package com.aca.acaonlinestore.repository;

import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.ProductRating;
import com.aca.acaonlinestore.entity.Store;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product,Long> {


    Page<Product> findByNameContaining(String keyword, Pageable pageable);

    @Query("SELECT p FROM Product p LEFT JOIN FETCH p.store s " +
            "WHERE (:category is null OR p.category = :category) " +
            "AND (:minPrice is null OR p.price >= :minPrice) " +
            "AND (:maxPrice is null OR p.price <= :maxPrice)"+
            "AND (:store is null OR p.store = :store)"+
            "AND (:minRate is null OR p.averageRate >= :minRate)"+
            "AND (:maxRate is NULL OR p.averageRate <= :maxRate)"+
            "AND (:minimumQuantity IS NULL OR p.availability >= :minimumQuantity )")
    Page<Product> filter(@Param("category") Category category,
                            @Param("minPrice") Double minPrice,
                            @Param("maxPrice") Double maxPrice,
                            @Param("store") Store store,
                            @Param("minRate") Integer minRate,
                            @Param("maxRate") Integer maxRate,
                            @Param("minimumQuantity") Integer minimumQuantity,
                            Pageable pageable);

}
