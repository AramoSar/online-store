package com.aca.acaonlinestore.model.courier;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderCourierRequestJson {
    private long orderId;
    private String fullName;
    private String country;
    private String city;
    private String address;
    private String phone;
    private String zipCode;
    private double weightKg;
    private Size size;
    private double deliveryPrice;
    private double totalPrice;

    public enum Size {
        SMALL, MEDIUM, LARGE, EXTRA_LARGE
    }
}

/*
* "orderId":"orderId",
    "fullName":"fullName",
    "country":"Armenia",
    "city":"Yerevan",
    "address":"Halabyan",Or
    "phone":"011-22-33-44",
    "zipCode":"0001",
    "weightKg":6.3,
    "size":"SMALL",
    "deliveryPrice":12.5,
    "totalPrice":50.8
* */
