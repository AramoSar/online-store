package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.converter.CategoryConverter;
import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.model.CategoryDTO;
import com.aca.acaonlinestore.service.CategoriesService;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/category")
public class CategoriesRestController {

    CategoriesService categoriesService;
    private final CategoryConverter categoryConverter;

    @Autowired
    public CategoriesRestController(CategoriesService categoriesService, CategoryConverter categoryConverter) {
        this.categoriesService = categoriesService;
        this.categoryConverter = categoryConverter;
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @GetMapping("/{categoryId}")
    public CategoryDTO getCategories(@PathVariable("categoryId") long categoryId) {
        Category category = categoriesService.getCategoryById(categoryId);
        return categoryConverter.convertToModel(category, new CategoryDTO());
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @GetMapping("/all")
    public List<CategoryDTO> getAllCategories() {
        List<Category> allCategories = categoriesService.getAllCategories();
        List<CategoryDTO> allCategoriesDTO = new ArrayList<>();
        for (Category c : allCategories) {
            CategoryDTO currentCategoryDTO = categoryConverter.convertToModel(c, new CategoryDTO());
            allCategoriesDTO.add(currentCategoryDTO);
        }
        return allCategoriesDTO;
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @PostMapping("/add")
    public long addCategory(@RequestBody CategoryDTO categoryDTO) {
        Category category = categoriesService.save(categoryDTO);
        return category.getId();
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @PutMapping("/{categoryId}")
    public long updateCategory(@PathVariable long categoryId, @RequestBody CategoryDTO categoryDTO) {
        Category category = categoriesService.update(categoryId, categoryDTO);
        return category.getId();
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @DeleteMapping("/{categoryId}")
    public void removeCategory(@PathVariable long categoryId ) {
        categoriesService.deleteCategory(categoryId);
    }
}
