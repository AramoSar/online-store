package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.model.*;
import com.aca.acaonlinestore.model.courier.DeliveryPriceResponse;
import com.aca.acaonlinestore.model.courier.OrderCourierRequestJson;
import com.aca.acaonlinestore.model.courier.OrderCourierResponseJson;
import com.aca.acaonlinestore.model.courier.OrderDeliveryPrice;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
@Slf4j
public class CourierAPIClientService {
    private static final String COURIER_API_URL = "http://192.168.10.97:8080";
    private static final String apiKey = "zly+0a0JTPXAjGBl8GM+NV5ECwnMe/8qEGeO5zmXk+A=";
    private static final String apiSecret = "+2htofax3Nomi2s0HmQpF5uk3+Lm2PlAgsbPQ5sTU7Q=";


    /**
     * The method sends request to Courier Service.
     * Response body is converted to corresponding class and returned.
     * Request url is 'COURIER_API_URL' + /order/create with POST method.
     * In request, we set headers "apikey" and "apisecret" which we have from courier service team
     * to have access to their endpoint. (So that we don't need to be their user)
     * @param order, which is Order entity converted to appropriate class for Courier Service
     * @return orderCourierResponseJson, which contains status and tracking number
     * */
    public static OrderCourierResponseJson sendOrderToCourierService(OrderCourierRequestJson order) throws URISyntaxException, IOException, InterruptedException {
        ObjectMapper objectMapper = new ObjectMapper();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(COURIER_API_URL + "/order/create"))
                .header("Content-type", "application/json;charset=UTF-8")
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(order)))
                .build();
        log.info("Http request is ready to be sent!", request);
        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String body = httpResponse.body();
        log.info("Response body", body);

        OrderCourierResponseJson orderCourierResponseJson = objectMapper.readValue(body, OrderCourierResponseJson.class);

        return orderCourierResponseJson;
    }

    // "/order/tracking/trackingId - GET"
    /**
     * The method sends request to Courier Service.
     * Response body is converted to corresponding class and returned.
     * Request url is 'COURIER_API_URL' + /order/tracking/trackingId with GET method.
     * In request, we set headers "apikey" and "apisecret" which we have from courier service team
     * to have access to their endpoint. (So that we don't need to be their user)
     * @param trackingId, which is get from order
     * @return orderStatusHistoryJsons, which contains status updated, date and additional info
     * */
    public static OrderStatusHistoryJson[] getOrderStatusUpdate(String trackingId) throws URISyntaxException, IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(COURIER_API_URL + "/order/tracking/" + trackingId))
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .GET()
                .build();
        log.info("Http request is ready to be sent!", request);

        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String body = response.body();
        log.info("Response body", body);

        ObjectMapper objectMapper = new ObjectMapper();
        OrderStatusHistoryJson[] orderStatusHistoryJsons = objectMapper.readValue(body, OrderStatusHistoryJson[].class);


        return orderStatusHistoryJsons;
    }


    // Returns the delivery price from courier service
    public static double deliveryPriceCalc(OrderDeliveryPrice orderDeliveryPrice) throws IOException, InterruptedException, URISyntaxException {
        ObjectMapper objectMapper = new ObjectMapper();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(COURIER_API_URL + "/order/calculate"))
                .header("Content-type", "application/json;charset=UTF-8")
                .header("apikey", apiKey)
                .header("apisecret", apiSecret)
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(orderDeliveryPrice)))
                .build();

        HttpClient httpClient = HttpClient.newHttpClient();
        HttpResponse<String> httpResponse = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String body = httpResponse.body();

        DeliveryPriceResponse deliveryPriceResponse = objectMapper.readValue(body, DeliveryPriceResponse.class);

        return deliveryPriceResponse.getDeliveryPrice();
    }

}
