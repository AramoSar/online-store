package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Cart;
import com.aca.acaonlinestore.entity.CartProduct;
import com.aca.acaonlinestore.model.CartDTO;
import com.aca.acaonlinestore.model.CartProductDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CartConverter implements Converter <CartDTO, Cart>{

    @Override
    public Cart convertToEntity(CartDTO model, Cart entity) {
        entity.setId(model.getId());
        entity.setSubtotal(model.getSubtotal());

        CartProductConverter cartProductConverter = new CartProductConverter();
        List<CartProduct> cartProductList = new ArrayList<>();
        for (CartProductDTO cartProductDTO : model.getCartProductsDTO()) {
            CartProduct cartProduct = cartProductConverter.convertToEntity(cartProductDTO, new CartProduct());
            cartProductList.add(cartProduct);
        }
        entity.setCartProducts(cartProductList);

        return entity;
    }

    @Override
    public CartDTO convertToModel(Cart entity, CartDTO model) {
        model.setId(entity.getId());
        model.setSubtotal(entity.getSubtotal());

        CartProductConverter cartProductConverter = new CartProductConverter();
        List<CartProductDTO> cartProductsDTO = new ArrayList<>();
        for (CartProduct cartProduct : entity.getCartProducts()) {
            CartProductDTO cartProductDTO = cartProductConverter.convertToModel(cartProduct, new CartProductDTO());
            cartProductsDTO.add(cartProductDTO);
        }

        model.setCartProductsDTO(cartProductsDTO);
        return model;
    }
}
