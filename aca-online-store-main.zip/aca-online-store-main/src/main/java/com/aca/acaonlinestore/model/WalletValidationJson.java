package com.aca.acaonlinestore.model;

import lombok.Data;

@Data
public class WalletValidationJson {
    private String siteName;
    private String key;
}
