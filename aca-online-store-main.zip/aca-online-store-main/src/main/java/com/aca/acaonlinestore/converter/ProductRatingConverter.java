package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.ProductRating;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.model.ProductRatingDTO;
import com.aca.acaonlinestore.repository.ProductRepository;
import com.aca.acaonlinestore.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProductRatingConverter implements Converter<ProductRatingDTO,ProductRating>{
    ProductRepository productRepository;
    UserRepository userRepository;

    @Autowired
    public ProductRatingConverter(ProductRepository productRepository, UserRepository userRepository){
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }
    @Override
    public ProductRating convertToEntity(ProductRatingDTO model, ProductRating entity) {
        entity.setRate(model.getRate());
        entity.setReview(model.getReview());
        Product product = productRepository.getReferenceById(model.getProductId());
        entity.setRatedProduct(product);
        User user = userRepository.getReferenceById(model.getUserId());
        entity.setUser(user);
        return entity;
    }

    @Override
    public ProductRatingDTO convertToModel(ProductRating entity, ProductRatingDTO model) {
        model.setId(entity.getId());
        model.setRate(entity.getRate());
        model.setReview(entity.getReview());
        model.setProductId(entity.getRatedProduct().getId());
        model.setUserId(entity.getUser().getId());
        return model;
    }
}
