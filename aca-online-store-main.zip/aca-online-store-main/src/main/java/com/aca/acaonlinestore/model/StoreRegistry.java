package com.aca.acaonlinestore.model;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StoreRegistry {
    @Valid
    private StoreDTO storeDto;
    @Valid
    private UserDTO storeAdmin;
}
