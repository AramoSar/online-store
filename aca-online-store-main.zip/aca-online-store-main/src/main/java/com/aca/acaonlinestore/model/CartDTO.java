package com.aca.acaonlinestore.model;

import com.aca.acaonlinestore.entity.CartProduct;
import com.aca.acaonlinestore.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartDTO {
    private long id;
    private double subtotal;
    private List<CartProductDTO> cartProductsDTO;
}
