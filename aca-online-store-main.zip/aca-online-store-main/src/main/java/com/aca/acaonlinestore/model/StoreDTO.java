package com.aca.acaonlinestore.model;


import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class StoreDTO {
    private long id;

    @NotNull(message = "The name can not be null")
    private String name;

    @NotNull(message = "The description can not be null")
    private String description;

    private AddressDTO addressDTO;

    @Min(1)
    @Max(5)
    private double rating;
}
