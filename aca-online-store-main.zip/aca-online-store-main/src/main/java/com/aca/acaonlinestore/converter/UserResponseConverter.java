package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.UserResponseJson;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserResponseConverter implements Converter<UserResponseJson, User>{
    @Override
    public User convertToEntity(UserResponseJson model, User entity) {
        return null;
    }

    @Override
    public UserResponseJson convertToModel(User entity, UserResponseJson model) {
        model.setId(entity.getId());
        model.setUsername(entity.getUsername());
        model.setEmail(entity.getEmail());
        model.setPhoneNumber(entity.getPhoneNumber());
        List<AddressDTO> addressDTO = new ArrayList<>();
        for (Address deliverAddress : entity.getDeliverAddress()) {
            AddressDTO currentAddressDTO = new AddressDTO();
            currentAddressDTO.setCity(deliverAddress.getCity());
            currentAddressDTO.setStreet(deliverAddress.getStreet());
            currentAddressDTO.setCountry(deliverAddress.getCountry());
            currentAddressDTO.setPostalCode(deliverAddress.getPostalCode());
            addressDTO.add(currentAddressDTO);
        }
        model.setAddress(addressDTO);
        return model;
    }
}
