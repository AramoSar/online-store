package com.aca.acaonlinestore.exception;

public class ProductNotFoundException extends Exception{
    public ProductNotFoundException(String str){
        super(str);
    }
    public ProductNotFoundException(String str, Throwable throwable){
        super(str,throwable);
    }
}
