package com.aca.acaonlinestore.model.courier;

import lombok.Data;

@Data
public class DeliveryPriceResponse {
    private double deliveryPrice;
    private String currency;
}
