package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.model.LoginJson;
import com.aca.acaonlinestore.model.ResponseJson;
import com.aca.acaonlinestore.model.UserDTO;
import com.aca.acaonlinestore.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final AuthenticationManager authenticationManager;
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public AuthController(AuthenticationManager authenticationManager, UserService userService, PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody UserDTO userDTO) {
        if (userService.userExists(userDTO.getUsername(), userDTO.getEmail())) {
            return new ResponseEntity<>(new ResponseJson("User with this credentials already exists!", "Failed"), HttpStatus.BAD_REQUEST);
        }

        userService.saveUser(userDTO, passwordEncoder.encode(userDTO.getPassword()), User.Role.ROLE_USER);

        return new ResponseEntity<>(new ResponseJson("User registered", "Success"), HttpStatus.OK);
    }


    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginJson loginJson, HttpServletRequest request) throws Exception {
        try {
            Authentication authObject = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginJson.getLogin(), loginJson.getPassword()));
            SecurityContext securityContext = SecurityContextHolder.getContext();
            securityContext.setAuthentication(authObject);

            // Create a new session and add the security context.
             HttpSession session = request.getSession(true);
             session.setAttribute("SPRING_SECURITY_CONTEXT", securityContext);
        } catch (BadCredentialsException e) {
            e.printStackTrace();
            return new ResponseEntity<>(new ResponseJson("Invalid credentials", "Failed"), HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(new ResponseJson("User logged in", "Success"), HttpStatus.OK);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request) {
        SecurityContextHolder.getContext().setAuthentication(null);
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        return new ResponseEntity<>(new ResponseJson("User logged out", "Success"), HttpStatus.OK);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException exception) {
        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError)error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}
