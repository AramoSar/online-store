package com.aca.acaonlinestore.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class LoginJson {
    @NotEmpty(message = "Field can't be empty")
    private String login;

    @NotEmpty(message = "Field can't be empty")
    private String password;
}
