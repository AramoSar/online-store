package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.Store;
import com.aca.acaonlinestore.model.ProductDTO;
import com.aca.acaonlinestore.model.StoreRegistry;
import com.aca.acaonlinestore.repository.CategoryRepository;
import com.aca.acaonlinestore.repository.StoreRepository;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;


@Component
public class ProductConverter implements Converter<ProductDTO, Product>{

    StoreRepository storeRepository;
    CategoryRepository categoryRepository;
    @Autowired
    public ProductConverter(StoreRepository storeRepository, CategoryRepository categoryRepository){
        this.categoryRepository = categoryRepository;
        this.storeRepository = storeRepository;
    }
    public ProductConverter(){}

    @Override
    public Product convertToEntity(ProductDTO model, Product entity) {

        entity.setName(model.getName());
        entity.setDescription(model.getDescription());
        entity.setPrice(model.getPrice());
        entity.setAvailability(model.getAvailability());
        entity.setAverageRate(model.getAverageRate());
        entity.setWeightKg(model.getWeightKg());

        Optional<Store> store = storeRepository.findById(model.getStoreId());
        entity.setStore(store.orElse(null));

        Optional<Category> category = categoryRepository.findById(model.getCategoryId());
        entity.setCategory(category.orElse(null));
        return entity;
    }

    @Override
    public ProductDTO convertToModel(Product entity, ProductDTO model) {
        model.setId(entity.getId());
        model.setName(entity.getName());
        model.setDescription(entity.getDescription());
        model.setPrice(entity.getPrice());
        model.setAvailability(entity.getAvailability());
        model.setAverageRate(entity.getAverageRate());
        model.setWeightKg(entity.getWeightKg());
        model.setStoreId(entity.getStore().getId());
        model.setCategoryId(entity.getCategory().getId());
        model.setCategoryName(entity.getCategory().getName());
        return model;
    }
}
