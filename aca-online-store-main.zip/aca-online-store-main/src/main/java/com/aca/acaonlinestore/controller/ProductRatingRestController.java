package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.converter.ProductRatingConverter;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.ProductRating;
import com.aca.acaonlinestore.model.ProductRatingDTO;
import com.aca.acaonlinestore.repository.ProductRepository;
import com.aca.acaonlinestore.service.ProductRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.attribute.standard.Media;
import java.awt.*;
import java.util.Optional;

@RestController
@RequestMapping("/productRatings")

public class ProductRatingRestController {
    private ProductRatingService productRatingService;
    private ProductRepository productRepository;

    @Autowired
    public ProductRatingRestController(ProductRatingService productRatingService,
                                       ProductRepository productRepository){
        this.productRatingService = productRatingService;
        this.productRepository = productRepository;
    }

    @GetMapping( value = "/{product_id}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Double> createMeanRate(@PathVariable Long product_id){
        Optional<Product> opt = productRepository.findById(product_id);
        Product product = opt.orElse(null);
        double finalRate = productRatingService.createMeanRate(product_id);
        assert product != null;
        product.setAverageRate(finalRate);
        return ResponseEntity.ok(finalRate);
    }

    @PostMapping( value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ProductRatingDTO> createProductRating(@RequestBody ProductRatingDTO productRatingDTO){
        productRatingDTO = productRatingService.createProductRating(productRatingDTO);
        return ResponseEntity.ok(productRatingDTO);

    }
}












