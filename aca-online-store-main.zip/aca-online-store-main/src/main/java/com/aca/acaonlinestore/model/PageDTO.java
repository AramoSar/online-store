package com.aca.acaonlinestore.model;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageDTO<T> {
    @NotEmpty
    private List<T> content;
    @NotEmpty
    private int pageNumber;
    @NotEmpty
    private int pageSize;
    @NotEmpty
    private int totalElements;
    @NotEmpty
    private int totalPages;


}
