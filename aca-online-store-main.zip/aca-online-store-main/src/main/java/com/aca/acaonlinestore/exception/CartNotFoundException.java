package com.aca.acaonlinestore.exception;

public class CartNotFoundException extends Exception{
    public CartNotFoundException(String str){
        super(str);
    }
    public CartNotFoundException(String str, Throwable throwable){
        super(str,throwable);
    }
}
