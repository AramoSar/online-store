package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.model.CategoryDTO;
import org.springframework.stereotype.Component;

@Component
public class CategoryConverter implements Converter <CategoryDTO, Category>{


    @Override
    public Category convertToEntity(CategoryDTO model, Category entity) {
        entity.setName(model.getName());
        entity.setDescription(model.getDescription());
        //entity.setProducts(model.getProducts());
        return entity;
    }

    @Override
    public CategoryDTO convertToModel(Category entity, CategoryDTO model) {
        model.setId(entity.getId());
        model.setName(entity.getName());
        model.setDescription(entity.getDescription());
        //model.setProducts(entity.getProducts());
        return model;
    }
}
