package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.StatusHistory;
import com.aca.acaonlinestore.model.StatusHistoryDTO;
import org.springframework.stereotype.Component;

@Component
public class StatusHistoryConverter implements Converter<StatusHistoryDTO, StatusHistory>{
    @Override
    public StatusHistory convertToEntity(StatusHistoryDTO model, StatusHistory entity) {
        entity.setStatusTo(model.getStatusTo());
        entity.setStatusFrom(model.getStatusFrom());
        entity.setReason(model.getReason());
        entity.setDateOfChange(model.getDateOfChange());
        return entity;
    }

    @Override
    public StatusHistoryDTO convertToModel(StatusHistory entity, StatusHistoryDTO model) {
        model.setId(entity.getId());
        model.setStatusTo(entity.getStatusTo());
        model.setStatusFrom(entity.getStatusFrom());
        model.setDateOfChange(entity.getDateOfChange());
        model.setReason(entity.getReason());
        return model;
    }
}
