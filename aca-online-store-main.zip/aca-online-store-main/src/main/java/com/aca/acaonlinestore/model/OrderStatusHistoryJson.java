package com.aca.acaonlinestore.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderStatusHistoryJson {
    private Date updateTime;
    private String updatedFrom;
    private String updatedTo;
    private String additionalInfo;
    private long orderId;
}

/*
* "statusUpdateHistory": [
        {
            "updateTime": "2023-10-01T17:11:59.082939",
            "updatedFrom": null,
            "updatedTo": "NEW",
            "additionalInfo": "Created new order",
            "orderId": 1
        }
        * {
            "updateTime": "2023-10-01T17:11:59.082939",
            "updatedFrom": NEW,
            "updatedTo": "SHIPPED",
            "additionalInfo": "Created new order",
            "orderId": 1
        }
    ]

* */
