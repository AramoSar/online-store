package com.aca.acaonlinestore.model;

import lombok.Data;

@Data
public class CartRequestJson {
    private long productId;
    private int quantity;
}
