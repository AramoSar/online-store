package com.aca.acaonlinestore.entity;

public enum Status {
    CREATED,
    PAID,
    CANCELED,
    SHIPPED,
    DELIVERED
}
