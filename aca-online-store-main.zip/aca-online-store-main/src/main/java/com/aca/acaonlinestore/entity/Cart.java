package com.aca.acaonlinestore.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Setter
@Getter
@Table(name = "shopping_cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @OneToOne(mappedBy = "cart")
    private User user;

    @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL)
    private List<CartProduct> cartProducts;

    @Column(name = "subtotal")
    private double subtotal;

    public Cart(User user, List<CartProduct> cartProducts) {
        this.user = user;
        this.cartProducts = cartProducts;
    }

    public Cart(List<Product> products) {
        this.cartProducts = getCartProducts();
    }

    public Cart() {

    }
}
