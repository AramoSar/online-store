package com.aca.acaonlinestore.exception;

public class PaymentNotDoneException extends RuntimeException{
    public PaymentNotDoneException(String message) {
        super(message);
    }

    public PaymentNotDoneException(String message, Throwable cause) {
        super(message, cause);
    }
}
