package com.aca.acaonlinestore.model.courier;

import lombok.Data;

@Data
public class OrderDeliveryPrice {
    private double weightKg;
    private OrderCourierRequestJson.Size size;
    private String country;



    //{
      //  "weightKg": 0.5,
        //    "size":"large",
          //  "country":"Country"
    //}
}
