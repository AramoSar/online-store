package com.aca.acaonlinestore.controller;


import com.aca.acaonlinestore.converter.OrderConverter;
import com.aca.acaonlinestore.entity.Order;
import com.aca.acaonlinestore.exception.ProductNotFoundException;
import com.aca.acaonlinestore.model.OrderDTO;
import com.aca.acaonlinestore.model.OrderRequestJson;
import com.aca.acaonlinestore.service.OrderService;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderRestController {
    private final OrderService orderService;
    private final OrderConverter orderConverter;

    @Autowired
    public OrderRestController(OrderService orderService, OrderConverter orderConverter) {
        this.orderService = orderService;
        this.orderConverter = orderConverter;
    }

    @RolesAllowed({"GLOBAL_ADMIN","USER"})
    @RequestMapping(value = "/{orderId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public OrderDTO getOrder(@PathVariable long orderId) throws URISyntaxException, IOException, InterruptedException {
        Order order = orderService.getOrder(orderId);
        return orderConverter.convertToModel(order,new OrderDTO());
    }

    @RolesAllowed({"GLOBAL_ADMIN","USER"})
    @RequestMapping(value = "/list",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public List<OrderDTO> listOrders() throws URISyntaxException, IOException, InterruptedException {
        return orderService.getOrderList();
    }

    @RolesAllowed("USER")
    @RequestMapping(value = "/createfromproduct",method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public OrderDTO createFromProduct(@RequestBody OrderRequestJson orderRequestJson) throws ProductNotFoundException, URISyntaxException, IOException, InterruptedException {
        return orderService.createFromProduct(orderRequestJson);
    }

    @RolesAllowed("USER")
    @RequestMapping(value = "/createfromcart/{addressId}",method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public OrderDTO createfromcart(@PathVariable long addressId) throws URISyntaxException, IOException, InterruptedException {
        return orderService.createFromCart(addressId);
    }
}
