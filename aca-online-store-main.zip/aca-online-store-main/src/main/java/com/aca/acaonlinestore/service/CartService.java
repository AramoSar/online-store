package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.CartConverter;
import com.aca.acaonlinestore.entity.Cart;
import com.aca.acaonlinestore.entity.CartProduct;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.exception.ProductNotFoundException;
import com.aca.acaonlinestore.model.CartRequestJson;
import com.aca.acaonlinestore.repository.CartProductRepository;
import com.aca.acaonlinestore.repository.CartRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    CartRepository cartRepository;
    private final CartProductRepository cartProductRepository;
    private final UserService userService;
    private final ProductService productService;
    private final CartConverter cartConverter;
    @Autowired
    public CartService(CartRepository cartRepository, CartProductRepository cartProductRepository, UserService userService, ProductService productService, CartConverter cartConverter) {
        this.cartRepository = cartRepository;
        this.cartProductRepository = cartProductRepository;
        this.userService = userService;
        this.productService = productService;
        this.cartConverter = cartConverter;
    }

    public Cart viewCart(String email) {
        User user = userService.getUserByEmail(email);

        return user.getCart();
    }

    @Transactional
    public Cart emptyCart(String email) {
        User user = userService.getUserByEmail(email);
        Cart cart = user.getCart();
        cart.getCartProducts().stream().map(cp->cp.getId()).forEach(cartProductRepository::deleteById);
        cart.setSubtotal(0);
        cart.getCartProducts().clear();
        return cart;
    }

    @Transactional
    public Cart addToCart(String email, CartRequestJson cartRequestJson) throws ProductNotFoundException {
        User user = userService.getUserByEmail(email);
        Cart cart = user.getCart();
        List<CartProduct> cartProducts = cart.getCartProducts();
        CartProduct newCartProduct = new CartProduct();
        Product product = productService.getProductById(cartRequestJson.getProductId());
        boolean flag = false;
        for (CartProduct cartProduct : cartProducts) {
            if (cartProduct.getProduct().equals(product)) {
                int quantity = cartProduct.getQuantity();
                quantity+=cartRequestJson.getQuantity();
                cartProduct.setQuantity(quantity);
                flag = true;
            }
        }
        if (!flag) {
            newCartProduct.setProduct(product);
            newCartProduct.setCart(cart);
            newCartProduct.setQuantity(cartRequestJson.getQuantity());
            cartProducts.add(newCartProduct);
        }
        double subtotal =0;
        for (CartProduct cartProduct : cart.getCartProducts()) {
            double price = cartProduct.getProduct().getPrice();
            int quantity = cartProduct.getQuantity();
            double currentPrice = quantity * price;
            subtotal+=currentPrice;
        }
        cart.setSubtotal(subtotal);
        return cartRepository.save(cart);
    }

    @Transactional
    public Cart removeFromCart(String email, long productId) {
        User user = userService.getUserByEmail(email);
        Cart cart = user.getCart();
        List<CartProduct> cartProducts = cart.getCartProducts();
        CartProduct cartProduct = cartProducts.stream().filter((cp) -> cp.getProduct().getId() == productId)
                .findFirst().orElseThrow();

        cartProductRepository.deleteById(cartProduct.getId());
        cart.getCartProducts().remove(cartProduct);

        return cart;

    }
}
