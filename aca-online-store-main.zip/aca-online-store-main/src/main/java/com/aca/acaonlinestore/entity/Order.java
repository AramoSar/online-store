package com.aca.acaonlinestore.entity;

import com.aca.acaonlinestore.model.courier.OrderCourierRequestJson;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id")
    private User user;

    @OneToMany(mappedBy = "order")
    private List<OrderProduct> orderProduct;

    @Column(name = "totalPrice")
    private double totalPrice;

    @Column(name = "deliveryPrice")
    private double deliveryPrice;

    @Column(name = "size")
    private OrderCourierRequestJson.Size size;

    @Column(name = "totalWeight")
    private double totalWeight;

    @ManyToOne
    @JoinColumn(name = "address_id")
    private Address address;

    private Date date;

    @Column(name = "tracking_id")
    private String trackingId;

    @Enumerated(EnumType.STRING)
    private Status status;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<StatusHistory> statusHistory;

}
