package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.converter.AddressConverter;
import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.ResponseJson;
import com.aca.acaonlinestore.model.UserDTO;
import com.aca.acaonlinestore.model.UserResponseJson;
import com.aca.acaonlinestore.service.UserService;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/profile")
public class UserController {
    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private  final AddressConverter addressConverter;

    @Autowired
    public UserController(UserService userService, AuthenticationManager authenticationManager, AddressConverter addressConverter) {
        this.userService = userService;
        this.authenticationManager = authenticationManager;
        this.addressConverter = addressConverter;
    }

    @PutMapping
    @RolesAllowed({"GLOBAL_ADMIN", "USER", "STORE_ADMIN"})
    public ResponseEntity<?> updateUser(@RequestBody UserDTO userDTO) {
        UserDetails principal = userService.getAuthUserPrincipal();
        User user = userService.updateUser(principal.getUsername(), userDTO);


        Authentication authObject = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
        SecurityContext securityContext = SecurityContextHolder.getContext();
        securityContext.setAuthentication(authObject);

        return new ResponseEntity<>(new ResponseJson("User details updated", "Success"), HttpStatus.OK);
    }

    @GetMapping
    @RolesAllowed({"GLOBAL_ADMIN", "USER", "STORE_ADMIN"})
    public UserResponseJson getUser() {
        UserDetails principal = userService.getAuthUserPrincipal();
        return userService.getUserInfo(principal.getUsername());
    }

    @DeleteMapping
    @RolesAllowed("USER")
    public ResponseEntity<?> deleteUser() {
        UserDetails principal = userService.getAuthUserPrincipal();
        boolean deletedUser = userService.deleteUser(principal.getUsername());
        if (deletedUser) {
            return new ResponseEntity<>(new ResponseJson("User deleted", "Success"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ResponseJson("User not deleted", "Failed"), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @DeleteMapping("/{userId}")
    @RolesAllowed("GLOBAL_ADMIN")
    public ResponseEntity<?> deleteUser(@PathVariable long userId) {
        User user = userService.getUserById(userId);
        boolean deletedUser = userService.deleteUser(user.getEmail());
        if (deletedUser) {
            return new ResponseEntity<>(new ResponseJson("User deleted", "Success"), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ResponseJson("User not deleted", "Failed"), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping("/addresses/add")
    @RolesAllowed("USER")
    public ResponseEntity<?> addAddress(@Valid @RequestBody AddressDTO addressDTO) {
        UserDetails principal = userService.getAuthUserPrincipal();
        userService.addAddress(principal.getUsername(), addressDTO);

        return new ResponseEntity<>(new ResponseJson("Address added", "Success"), HttpStatus.OK);
    }

    @PutMapping("/addresses/{addressId}")
    @RolesAllowed("USER")
    public ResponseEntity<?> updateAddress(@PathVariable long addressId, @RequestBody AddressDTO addressDTO) {
        UserDetails principal = userService.getAuthUserPrincipal();
        userService.updateUserAddress(principal.getUsername(), addressId, addressDTO);
        return new ResponseEntity<>(new ResponseJson("Address updated", "Success"), HttpStatus.OK);
    }

    @GetMapping("/addresses/{addressId}")
    @RolesAllowed("USER")
    public AddressDTO getUserAddress(@PathVariable long addressId) {
        UserDetails principal = userService.getAuthUserPrincipal();
        Address addressById = userService.getAddressById(principal.getUsername(), addressId);
        return addressConverter.convertToModel(addressById,new AddressDTO());
    }

    @DeleteMapping("/addresses/{addressId}")
    @RolesAllowed("USER")
    public ResponseEntity<?> deleteAddress(@PathVariable long addressId) {
        UserDetails principal = userService.getAuthUserPrincipal();
        userService.deleteAddress(principal.getUsername(), addressId);
        return new ResponseEntity<>(new ResponseJson("Address deleted", "Success"), HttpStatus.OK);
    }

    @GetMapping("/addresses/list")
    @RolesAllowed("USER")
    public List<AddressDTO> getAllAddresses() {
        UserDetails principal = userService.getAuthUserPrincipal();
        return userService.getAllAddresses(principal.getUsername());
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException exception) {
        Map<String, String> errors = new HashMap<>();
        exception.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError)error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}