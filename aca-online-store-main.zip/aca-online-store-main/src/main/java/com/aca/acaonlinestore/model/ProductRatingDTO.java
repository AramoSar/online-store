package com.aca.acaonlinestore.model;

import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.User;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductRatingDTO {
    private long id;
    @Min(1)
    @Max(5)
    private int rate;
    private String review;
    private long productId;
    private long userId;
}
