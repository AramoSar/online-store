package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.entity.CartProduct;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.model.CartProductDTO;
import com.aca.acaonlinestore.model.ProductDTO;
import org.springframework.stereotype.Component;

@Component
public class CartProductConverter implements Converter <CartProductDTO, CartProduct>{



    @Override
    public CartProduct convertToEntity(CartProductDTO model, CartProduct entity) {
        ProductConverter productConverter = new ProductConverter();
        entity.setQuantity(model.getQuantity());
        Product product = productConverter.convertToEntity(model.getProductDto(), entity.getProduct());
        entity.setProduct(product);

        return entity;
    }

    @Override
    public CartProductDTO convertToModel(CartProduct entity, CartProductDTO model) {
        model.setId(entity.getId());
        ProductConverter productConverter = new ProductConverter();
        ProductDTO productDto = productConverter.convertToModel(entity.getProduct(), new ProductDTO());
        model.setProductDto(productDto);
        model.setQuantity(entity.getQuantity());

        return model;
    }
}
