package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.model.ticket.TicketRequestJson;
import com.aca.acaonlinestore.model.ticket.TicketResponseJson;
import com.aca.acaonlinestore.service.SupportAPIClientService;
import com.aca.acaonlinestore.service.UserService;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URISyntaxException;

@RestController
@RequestMapping("/support")
public class SupportController {
    private final UserService userService;

    @Autowired
    public SupportController(UserService userService) {
        this.userService = userService;
    }


    @PostMapping("/create")
    @RolesAllowed("USER")
    public ResponseEntity<?> createTicket(@RequestBody TicketRequestJson ticketRequestJson) throws URISyntaxException, IOException, InterruptedException {
        String username = userService.getAuthUserPrincipal().getUsername();
        User user = userService.getUserByEmail(username);
        TicketResponseJson ticketResponseJson = SupportAPIClientService.createTicket(user.getId(), ticketRequestJson);
        return new ResponseEntity<>(ticketResponseJson, HttpStatus.OK);
    }

    @PutMapping("/close")
    @RolesAllowed("USER")
    public ResponseEntity<?> closeTicket() throws IOException, InterruptedException {
        String username = userService.getAuthUserPrincipal().getUsername();
        User user = userService.getUserByEmail(username);
        TicketResponseJson ticketResponseJson = SupportAPIClientService.closeTicket(user.getId());
        return new ResponseEntity<>(ticketResponseJson, HttpStatus.OK);
    }

    @PostMapping("/sendMessage")
    @RolesAllowed("USER")
    public ResponseEntity<?> sendMessage(@RequestBody TicketRequestJson ticket) throws IOException, InterruptedException {
        String email = userService.getAuthUserPrincipal().getUsername();
        User user = userService.getUserByEmail(email);
        TicketResponseJson ticketResponseJson = SupportAPIClientService.sendMessage(user.getId(), ticket);
        return new ResponseEntity<>(ticketResponseJson, HttpStatus.OK);
    }

    @GetMapping("/getMessage")
    @RolesAllowed("USER")
    public ResponseEntity<?> getMessage() throws IOException, InterruptedException {
        String email = userService.getAuthUserPrincipal().getUsername();
        User user = userService.getUserByEmail(email);
        TicketResponseJson ticketResponseJson = SupportAPIClientService.getMessage(user.getId());
        return new ResponseEntity<>(ticketResponseJson, HttpStatus.OK);
    }
}
