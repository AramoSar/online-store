package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.Store;
import com.aca.acaonlinestore.model.StoreDTO;
import com.aca.acaonlinestore.model.StoreRegistry;
import com.aca.acaonlinestore.repository.StoreRepository;
import com.aca.acaonlinestore.service.StoreService;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/store")
public class   StoreController {
    private final StoreService storeService;
    private final StoreRepository storeRepository;

    @Autowired
    public StoreController(StoreService storeService, StoreRepository storeRepository) {
        this.storeService = storeService;
        this.storeRepository = storeRepository;
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @RequestMapping(value = "/register",method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public StoreDTO registerStore(@Valid @RequestBody StoreRegistry storeRegistry){
        return storeService.registerStore(storeRegistry.getStoreDto(),storeRegistry.getStoreAdmin());
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @RequestMapping(value = "/list",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public List<StoreDTO> getStoreList(){
        return storeService.getAllStores();
    }


    @RequestMapping(value = "/{store_id}/rate", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Double> getStoreRating(@PathVariable long store_id){
        double rate = storeService.getRate(store_id);
        return ResponseEntity.ok(rate);
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @RequestMapping(value = "/{storeId}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public StoreDTO getStore(@PathVariable long storeId){
        return storeService.getStoreById(storeId);
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @RequestMapping(value = "/admin/update/{storeId}",method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public StoreDTO updateStore(@PathVariable long storeId, @RequestBody StoreDTO storeDto){
        storeService.updateStore(storeId, storeDto);
        return storeService.updateStore(storeId, storeDto);
    }

    @RolesAllowed("GLOBAL_ADMIN")
    @RequestMapping(value = "/{adminId}/{storeId}",method = RequestMethod.DELETE)
    public String deleteStore(@PathVariable long storeId, @PathVariable long adminId){
        storeService.deleteStoreById(storeId,adminId);
        return "The store is deleted";
    }

    @RolesAllowed("STORE_ADMIN")
    @RequestMapping(value = "/own",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public StoreDTO myStore(){
        return storeService.getMyStore();
    }
}
