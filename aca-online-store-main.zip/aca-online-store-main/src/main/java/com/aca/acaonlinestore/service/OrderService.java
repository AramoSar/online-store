package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.*;
import com.aca.acaonlinestore.entity.*;
import com.aca.acaonlinestore.exception.OrderNotFoundException;
import com.aca.acaonlinestore.exception.ProductNotFoundException;
import com.aca.acaonlinestore.model.*;
import com.aca.acaonlinestore.model.courier.OrderCourierRequestJson;
import com.aca.acaonlinestore.model.courier.OrderCourierResponseJson;
import com.aca.acaonlinestore.model.courier.OrderDeliveryPrice;
import com.aca.acaonlinestore.repository.OrderRepository;
import com.aca.acaonlinestore.repository.StatusHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class OrderService {
    private final OrderRepository orderRepository;
    private final OrderConverter orderConverter;
    private final UserService userService;
    private final ProductService productService;
    private final CartService cartService;
    private final StatusHistoryRepository statusHistoryRepository;
    


    @Autowired
    public OrderService(OrderRepository orderRepository, OrderConverter orderConverter, UserService userService, ProductService productService, AddressConverter addressConverter, ProductConverter productConverter, CartService cartService, StatusHistoryRepository statusHistoryRepository) {
        this.orderRepository = orderRepository;
        this.orderConverter = orderConverter;
        this.userService = userService;
        this.productService = productService;
        this.cartService = cartService;
        this.statusHistoryRepository = statusHistoryRepository;
    }

    @Transactional
    public Order getOrder(long orderId) throws URISyntaxException, IOException, InterruptedException {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        UserDetails principal = (UserDetails) auth.getPrincipal();
        User userByUsernameOrEmail = userService.getUserByEmail(principal.getUsername());
        List<Order> orders = userByUsernameOrEmail.getOrders();
        for (Order order : orders) {
            if (order.getId() == orderId) {
                List<StatusHistory> orderStatusHistory = getOrderStatusHistory(order.getTrackingId());
                StatusHistory statusHistory = orderStatusHistory.get(orderStatusHistory.size() - 1);
                order.setStatus(statusHistory.getStatusTo());
                order.setStatusHistory(orderStatusHistory);
                orderRepository.save(order);
                return order;
            }
        }
        throw new OrderNotFoundException("Order with the order Id not found");
    }

    @Transactional
    public List<OrderDTO> getOrderList() throws URISyntaxException, IOException, InterruptedException {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        UserDetails principal = (UserDetails) auth.getPrincipal();
        User userByUsernameOrEmail = userService.getUserByEmail(principal.getUsername());
        List<Order> orders = userByUsernameOrEmail.getOrders();
        List<OrderDTO> orderDTOList = new ArrayList<>();
        for (Order order : orders) {
            List<StatusHistory> orderStatusHistory = getOrderStatusHistory(order.getTrackingId());
            StatusHistory statusHistory = orderStatusHistory.get(orderStatusHistory.size() - 1);
            order.setStatus(statusHistory.getStatusTo());
            order.setStatusHistory(orderStatusHistory);
            orderRepository.save(order);
            orderDTOList.add(orderConverter.convertToModel(order, new OrderDTO()));
        }
        return orderDTOList;
    }

    public OrderCourierRequestJson.Size calculateOrderSize(double totalWeight) {
        if (totalWeight <= 1.0) {
            return OrderCourierRequestJson.Size.SMALL;
        } else if (totalWeight <= 5.0) {
            return OrderCourierRequestJson.Size.MEDIUM;
        } else if (totalWeight <= 10.0) {
            return OrderCourierRequestJson.Size.LARGE;
        } else if (totalWeight > 10.0) {
            return OrderCourierRequestJson.Size.EXTRA_LARGE;
        }
        throw new IllegalArgumentException("Weight must be set more than 0");
    }

    /**
     * This method creates order from product.
     * Gets logged-in user, creates new Order.
     * Sends request to Courier Service to create new delivery order, get response with tracking number,
     * sets tracking number to OrderDTO
     *
     * @return orderDTO with tracking id
     */
    @Transactional
    public OrderDTO createFromProduct(OrderRequestJson orderRequestJson) throws ProductNotFoundException, URISyntaxException, IOException, InterruptedException {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        UserDetails principal = (UserDetails) auth.getPrincipal();
        User userByUsernameOrEmail = userService.getUserByEmail(principal.getUsername());
        Product product = productService.getProductById(orderRequestJson.getProductId());
        OrderProduct orderProduct = new OrderProduct();
        orderProduct.setProduct(product);
        orderProduct.setQuantity(orderRequestJson.getQuantity());
        List<OrderProduct> orderProductList = new ArrayList<>();
        orderProductList.add(orderProduct);
        Order newOrder = new Order();
        Date date = new Date();
        newOrder.setOrderProduct(orderProductList);
        newOrder.setUser(userByUsernameOrEmail);
        newOrder.setDate(date);
        Address addressById = userService
                .getAddressById(userByUsernameOrEmail
                        .getEmail(), orderRequestJson.getAddressId());
        newOrder.setAddress(addressById);
        newOrder.setStatus(Status.CREATED);
        double totalWeight = 0;
        for (OrderProduct orderProduct1 : orderProductList) {
            totalWeight += orderProduct1.getProduct().getWeightKg() * orderProduct1.getQuantity();
        }
        OrderCourierRequestJson.Size size = calculateOrderSize(totalWeight);
        newOrder.setSize(size);
        newOrder.setTotalWeight(totalWeight);
        OrderDeliveryPrice orderDeliveryPrice = new OrderDeliveryPrice();
        orderDeliveryPrice.setSize(size);
        orderDeliveryPrice.setWeightKg(totalWeight);
        orderDeliveryPrice.setCountry(product.getStore().getAddress().getCountry());
        double deliveryPrice = CourierAPIClientService.deliveryPriceCalc(orderDeliveryPrice);
        newOrder.setTotalPrice(product.getPrice() * orderProduct.getQuantity() + deliveryPrice);
        List<StatusHistory> statusHistory = new ArrayList<>();
        newOrder.setStatusHistory(statusHistory);
//        boolean isPaid = WalletAPIClientService.validatePayment(key);
//        if (!isPaid){
//            newOrder.setStatus(Status.CANCELED);
//            throw new PaymentNotDoneException("The order is not paid");
//        }
//        newOrder.setStatus(Status.PAID);
        //TODO get key from Wallet team
        orderRepository.save(newOrder);

        OrderCourierRequestJson orderCourierRequestJson = orderConverter.convertToCourierJson(newOrder, new OrderCourierRequestJson());
        OrderCourierResponseJson orderCourierResponseJson = CourierAPIClientService.sendOrderToCourierService(orderCourierRequestJson);

        newOrder.setTrackingId(orderCourierResponseJson.getTrackingNumber());
        newOrder.setDeliveryPrice(orderCourierRequestJson.getDeliveryPrice());

        OrderDTO orderDTO = orderConverter.convertToModel(newOrder, new OrderDTO());
        orderRepository.save(newOrder);
        return orderDTO;
    }


    @Transactional
    public OrderDTO createFromCart(long addressId) throws URISyntaxException, IOException, InterruptedException {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        UserDetails principal = (UserDetails) auth.getPrincipal();
        User userByUsernameOrEmail = userService.getUserByEmail(principal.getUsername());

        List<CartProduct> cartProducts = userByUsernameOrEmail.getCart().getCartProducts();
        List<OrderProduct> orderProducts = new ArrayList<>();
        double price = 0.0;
        double  totalDeliveryPrice=0;
        for (CartProduct cartProduct : cartProducts) {
            OrderProduct orderProduct = new OrderProduct();
            orderProduct.setProduct(cartProduct.getProduct());
            orderProduct.setQuantity(cartProduct.getQuantity());
            orderProducts.add(orderProduct);
            OrderDeliveryPrice orderDeliveryPrice = new OrderDeliveryPrice();
            double weightKg = cartProduct.getProduct().getWeightKg();
            orderDeliveryPrice.setWeightKg(weightKg);
            OrderCourierRequestJson.Size size = calculateOrderSize(weightKg* cartProduct.getQuantity());
            orderDeliveryPrice.setSize(size);
            orderDeliveryPrice.setCountry(cartProduct.getProduct().getStore().getAddress().getCountry());
            double deliveryPrice = CourierAPIClientService.deliveryPriceCalc(orderDeliveryPrice);
            totalDeliveryPrice+=deliveryPrice;
            price += cartProduct.getProduct().getPrice() * cartProduct.getQuantity() + deliveryPrice;
        }

        Order order = new Order();
        Date date = new Date();
        order.setOrderProduct(orderProducts);
        order.setUser(userByUsernameOrEmail);
        order.setDate(date);
        order.setStatus(Status.CREATED);
        Address addressById = userService
                .getAddressById(userByUsernameOrEmail
                        .getEmail(), addressId);
        order.setAddress(addressById);
        order.setTotalPrice(price);
        double totalWeight = 0;
        for (OrderProduct orderProduct1 : orderProducts) {
            totalWeight += orderProduct1.getProduct().getWeightKg() * orderProduct1.getQuantity();
        }
        OrderCourierRequestJson.Size size = calculateOrderSize(totalWeight);
        order.setSize(size);
        order.setTotalWeight(totalWeight);
        order.setDeliveryPrice(totalDeliveryPrice);
        List<StatusHistory> statusHistory = new ArrayList<>();
        order.setStatusHistory(statusHistory);

        OrderCourierRequestJson orderCourierRequestJson = orderConverter.convertToCourierJson(order, new OrderCourierRequestJson());
        OrderCourierResponseJson orderCourierResponseJson = CourierAPIClientService.sendOrderToCourierService(orderCourierRequestJson);
        order.setTrackingId(orderCourierResponseJson.getTrackingNumber());
//        boolean isPaid = WalletAPIClientService.validatePayment(key);
//        if (!isPaid){
//            order.setStatus(Status.CANCELED);
//            throw new PaymentNotDoneException("The order is not paid");
//        }
//        order.setStatus(Status.PAID);
        //TODO get key from Wallet team
        orderRepository.save(order);
        cartService.emptyCart(userByUsernameOrEmail.getEmail());
        OrderDTO orderDTO = orderConverter.convertToModel(order, new OrderDTO());
        return orderDTO;
    }


    /**
     * @return List<StatusHistory>, list of status history returned by courier service method
     * */
    public List<StatusHistory> getOrderStatusHistory(String trackingId) throws URISyntaxException, IOException, InterruptedException {
        OrderStatusHistoryJson[] orderStatusUpdate = CourierAPIClientService.getOrderStatusUpdate(trackingId);

        List<StatusHistory> statusHistoryList = new ArrayList<>();
        for (OrderStatusHistoryJson statusHistoryJson : orderStatusUpdate) {
            StatusHistory st = new StatusHistory();
            if (statusHistoryJson.getUpdatedFrom() != null) {
                st.setStatusFrom(getStatusFromString(statusHistoryJson.getUpdatedFrom()));
            }
            st.setStatusTo(getStatusFromString(statusHistoryJson.getUpdatedTo()));
            st.setReason(statusHistoryJson.getAdditionalInfo());
            st.setDateOfChange(statusHistoryJson.getUpdateTime());
            statusHistoryList.add(st);
        }

        return statusHistoryList;
    }

    public Status getStatusFromString(String status) {
        switch (status) {
            case "SHIPPED", "DELIVERING" -> {
                return Status.SHIPPED;
            }
            case "DELIVERED" -> {
                return Status.DELIVERED;
            }
            case "CANCELLED" -> {
                return Status.CANCELED;
            }
            case "NEW" -> {
                return Status.CREATED;
            }
        }
        return null;
    }
}

