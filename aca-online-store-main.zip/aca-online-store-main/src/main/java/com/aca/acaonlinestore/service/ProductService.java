package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.ProductConverter;
import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.Store;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.exception.ProductNotFoundException;
import com.aca.acaonlinestore.model.PageDTO;
import com.aca.acaonlinestore.model.ProductDTO;
import com.aca.acaonlinestore.repository.CategoryRepository;
import com.aca.acaonlinestore.repository.ProductRepository;
import com.aca.acaonlinestore.repository.StoreRepository;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ProductService {
    private ProductRepository productRepository;
    private ProductConverter productConverter;
    private UserService userService;

    @Autowired
    public ProductService(ProductRepository productRepository, ProductConverter productConverter,
                          UserService userService){
        this.productRepository = productRepository;
        this.productConverter = productConverter;
        this.userService= userService;
    }
    @Transactional
    public ProductDTO createProduct(ProductDTO model){
        Product product = new Product();
        product = productConverter.convertToEntity(model, product);
        productRepository.save(product);
        return productConverter.convertToModel(product, model);
    }

    @Transactional
    public Product getProductById(long product_id) throws ProductNotFoundException {
        Optional<Product> product = productRepository.findById(product_id);
        if (product.isEmpty()){
            throw new ProductNotFoundException("No such product");
        }
        return product.get();
    }

    @Transactional
    public PageDTO<ProductDTO> searchProducts(String keyword, Pageable pageable) {
        Page<Product> products = productRepository.findByNameContaining(keyword, pageable);
        List<ProductDTO> productDTOs = products.getContent().stream()
                .map(product -> productConverter.convertToModel(product, new ProductDTO()))
                .collect(Collectors.toList());

        PageDTO<ProductDTO> pageDTO = new PageDTO<>(
                productDTOs,
                products.getNumber(),
                products.getSize(),
                (int) products.getTotalElements(),
                products.getTotalPages()
        );
        return pageDTO;
    }

    @Transactional
    public PageDTO<ProductDTO> filter(Category category, Double minPrice, Double maxPrice, Store store, Integer minRate, Integer maxRate, Integer minimumQuantity, Pageable pageable) {
        Page<Product> entities = productRepository.filter(category, minPrice, maxPrice, store, minRate, maxRate, minimumQuantity, pageable);
        List<ProductDTO> productDTOs = entities.getContent().stream()
                .map(product -> productConverter.convertToModel(product, new ProductDTO()))
                .collect(Collectors.toList());

        PageDTO<ProductDTO> pageDTO = new PageDTO<>(
                productDTOs,
                entities.getNumber(),
                entities.getSize(),
                (int) entities.getTotalElements(),
                entities.getTotalPages()
        );
        return pageDTO;
    }

    @Transactional
    public List<ProductDTO> getAllProducts(){
        UserDetails authUserPrincipal = userService.getAuthUserPrincipal();
        String username = authUserPrincipal.getUsername();
        User user = userService.getUserByEmail(username);
        Set<Product> products = user.getStore().getProducts();

        List<ProductDTO> models = products.stream().map(product -> productConverter.convertToModel(product, new ProductDTO())).sorted(new Comparator<ProductDTO>() {
            @Override
            public int compare(ProductDTO o1, ProductDTO o2) {
                int i = (int) (o1.getId() - o2.getId());
                return i;
            }
        }).collect(Collectors.toList());

        return models;
    }




    @Transactional
    public ProductDTO decreaseProductAvailability(long product_id) throws ProductNotFoundException {  //change to take a parameter according to which the availability will be decreased
        Optional<Product> productOptional = productRepository.findById(product_id);
        if (productOptional.isEmpty()){
            throw new ProductNotFoundException("No such product");
        }
        Product product = productOptional.get();
        if (product.getAvailability() == 0) {
            System.out.println("The product is no longer available");
            return productConverter.convertToModel(product,new ProductDTO());
        }
        int updatedAvailability = product.getAvailability() - 1;
        product.setAvailability(updatedAvailability);

        productRepository.save(product);
        System.out.println("Updated Availability: " + updatedAvailability);
        return productConverter.convertToModel(product, new ProductDTO());
    }

    @Transactional
    public ProductDTO updateProductName(String name, long product_id) throws ProductNotFoundException { //return Dto ?
        Optional<Product> productOptional = productRepository.findById(product_id);
        Product product = productOptional.get();
        product.setName(name);
        productRepository.save(product);
        return productConverter.convertToModel(product,new ProductDTO());
    }
    @Transactional
    public ProductDTO updateProductPrice(double price, long product_id) throws ProductNotFoundException {
        Optional<Product> productOptional = productRepository.findById(product_id);
        Product product = productOptional.get();
        product.setPrice(price);
        productRepository.save(product);
        return productConverter.convertToModel(product,new ProductDTO());
    }
    @Transactional
    public ProductDTO updateProductDescription(String description, long product_id) throws ProductNotFoundException {
        Optional<Product> productOptional = productRepository.findById(product_id);
        Product product = productOptional.get();
        product.setDescription(description);
        productRepository.save(product);
        return productConverter.convertToModel(product,new ProductDTO());
    }

    @Transactional
    public boolean deleteProduct(long product_id){
        productRepository.deleteById(product_id);
        return true;
    }

}
