package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.converter.ProductConverter;
import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.Store;
import com.aca.acaonlinestore.exception.ProductNotFoundException;
import com.aca.acaonlinestore.model.PageDTO;
import com.aca.acaonlinestore.model.ProductDTO;
import com.aca.acaonlinestore.service.ProductService;
import jakarta.annotation.security.RolesAllowed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/products")
public class ProductRestController {
    private final ProductService productService;
    private final ProductConverter productConverter;

    @Autowired
    public ProductRestController(ProductService productService, ProductConverter productConverter) {
        this.productService = productService;
        this.productConverter = productConverter;
    }


    @PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @RolesAllowed("STORE_ADMIN")
    public ResponseEntity<ProductDTO> createProduct(@RequestBody ProductDTO productDto) {
        ProductDTO productDTO1 = productService.createProduct(productDto);
        return ResponseEntity.ok(productDTO1);
    }

    @GetMapping(value = "/{product_id}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @RolesAllowed({"STORE_ADMIN", "GLOBAL_ADMIN"})
    public ResponseEntity<ProductDTO> getProductById(@PathVariable Long product_id) throws ProductNotFoundException {
        Product product = productService.getProductById(product_id);
        return ResponseEntity.ok(productConverter.convertToModel(product, new ProductDTO()));
    }

    @GetMapping("/search")
    public ResponseEntity<PageDTO<ProductDTO>> searchProducts(@RequestParam(name = "keyword", required = false) //make return type response entity
                                                    String keyword, Pageable pageable) {
        PageDTO<ProductDTO> result = productService.searchProducts(keyword, pageable);

        return ResponseEntity.ok(result);
    }

    @GetMapping("/filter")
    public ResponseEntity<PageDTO<ProductDTO>> filter(@RequestParam(name = "categoryId", required = false) Long categoryId,
                                                      @RequestParam(name = "minPrice", required = false) Double minPrice,
                                                      @RequestParam(name = "maxPrice", required = false) Double maxPrice,
                                                      @RequestParam(name = "storeId", required = false) Long storeId,
                                                      @RequestParam(name = "minRate", required = false) Integer minRate,
                                                      @RequestParam(name = "maxRate", required = false) Integer maxRate,
                                                      @RequestParam(name = "minimumQuantity", required = false) Integer minimumQuantity,
                                                      Pageable pageable) {
        Category category = null;
        if (categoryId != null) {
            category = new Category();
            category.setId(categoryId);
        }
        Store store = null;
        if (storeId != null) {
            store = new Store();
            store.setId(storeId);
        }
        PageDTO<ProductDTO> filteredProducts = productService.filter(category, minPrice, maxPrice, store, minRate, maxRate, minimumQuantity, pageable);

        return ResponseEntity.ok(filteredProducts);
    }


    @GetMapping()
    @RolesAllowed("STORE_ADMIN")
    public ResponseEntity<List<ProductDTO>> getAllProducts(){
        List<ProductDTO> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }


    @PutMapping(value = "/{product_id}/decreaseAvailability", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @RolesAllowed("STORE_ADMIN")
    public ResponseEntity<ProductDTO> decreaseProductAvailability(@PathVariable long product_id) throws ProductNotFoundException {
        ProductDTO productDto = productService.decreaseProductAvailability(product_id);

        return ResponseEntity.ok(productDto);
    }
    @PutMapping(value = "/{product_id}/updateProductName", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @RolesAllowed("STORE_ADMIN")
    public ResponseEntity<ProductDTO> updateProductName(@PathVariable Long product_id, @RequestParam String name)  {
        ProductDTO productDto = null;
        try {
            productDto = productService.updateProductName(name, product_id);
        } catch (ProductNotFoundException e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok(productDto);
    }
    @PutMapping(value = "/{product_id}/updateProductDescription", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @RolesAllowed("STORE_ADMIN")
    public ResponseEntity<ProductDTO> updateProductDescription(@PathVariable Long product_id, @RequestParam String description)  {
        ProductDTO productDto = null;
        try {
            productDto = productService.updateProductDescription(description, product_id);
        } catch (ProductNotFoundException e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok(productDto);
    }
    @PutMapping(value = "/{product_id}/updateProductPrice", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @RolesAllowed("STORE_ADMIN")
    public ResponseEntity<ProductDTO> updateProductPrice(@PathVariable Long product_id, @RequestParam Double price){
        ProductDTO productDto = null;
        try {
            productDto = productService.updateProductPrice(price,product_id);
        } catch (ProductNotFoundException e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok(productDto);
    }

    @DeleteMapping("/{product_id}")
    @RolesAllowed("STORE_ADMIN")
    public ResponseEntity<String> deleteProduct(@PathVariable Long product_id){
        boolean deleteProductById = productService.deleteProduct(product_id);
        if (deleteProductById){
            return new ResponseEntity<>(("Product deleted - Product ID:" + product_id), HttpStatus.OK);
        } return new ResponseEntity<>(("Product not deleted - Product ID:" + product_id), HttpStatus.BAD_REQUEST);

    }


}
