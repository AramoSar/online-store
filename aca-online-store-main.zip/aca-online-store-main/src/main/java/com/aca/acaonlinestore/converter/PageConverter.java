package com.aca.acaonlinestore.converter;

import com.aca.acaonlinestore.model.PageDTO;
import org.springframework.data.domain.Page;

public class PageConverter implements Converter<PageDTO, Page>{

    @Override
    public Page convertToEntity(PageDTO model, Page entity) {
        return null;
    }

    @Override
    public PageDTO convertToModel(Page entity, PageDTO model) {

        model.setContent(entity.getContent());
        model.setPageNumber(entity.getNumber());
        model.setPageSize(entity.getSize());
        model.setTotalPages(entity.getTotalPages());
        model.setTotalElements(entity.getNumberOfElements());
        return model;
    }
}
