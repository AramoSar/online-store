package com.aca.acaonlinestore.repository;

import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.Store;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class StoreRepositoryTests {
    @Autowired
    private StoreRepository storeRepository;

    @Test
    public void storeRepository_SaveAll_ReturnSavedStore(){
        Set<Product> products = new HashSet<>();
        Store store = new Store(1,"Supermarket","blablabla",5,products,new Address());

        Store savedStore = storeRepository.save(store);

        Assertions.assertNotNull(savedStore);
        Assertions.assertTrue(savedStore.getId()>0);
    }

    @Test
    public void storeRepository_GetAll_ReturnMoreThanOne(){
        Set<Product> products = new HashSet<>();
        Store store = new Store(1,"Supermarket","blablabla",5,products,new Address());
        Product apple1 = new Product();
        Product orange1 = new Product();
        Set<Product> productsList = new HashSet<>();
        Store store1 = new Store(2,"Supermarket2","blablablas",5,products,new Address());
        storeRepository.save(store);
        storeRepository.save(store1);

        List<Store> storeList = storeRepository.findAll();

        Assertions.assertNotNull(storeList);
        Assertions.assertEquals(2, storeList.size());
    }

    @Test
    public void storeRepository_FindById_ReturnStore() {
        Set<Product> products = new HashSet<>();
        Store store = new Store(1, "Supermarket", "blablabla", 5, products,new Address());

        Store savedStore = storeRepository.save(store); // Save the store and get the saved instance

        Optional<Store> storeOptional = storeRepository.findById(savedStore.getId());

        Assertions.assertTrue(storeOptional.isPresent()); // Check if the optional has a value

        Store store1 = storeOptional.get(); // Now it's safe to get the value

        Assertions.assertNotNull(store1);
    }




    @Test
    public void storeRepository_UpdateStore_ReturnStoreNotNull() {
        Set<Product> products = new HashSet<>();
        Store store = new Store(1, "Supermarket", "blablabla", 5, products,new Address());

        storeRepository.save(store);

        Optional<Store> optionalStore = storeRepository.findById(store.getId());
        if (optionalStore.isPresent()) {
            Store savedStore = optionalStore.get();
            savedStore.setName("Yerevan City");
            savedStore.setId(5L);

            Store updatedStore = storeRepository.save(savedStore);
            Assertions.assertNotNull(updatedStore.getName());
            Assertions.assertEquals(5, updatedStore.getId());
        }
    }

    @Test
    public void storeRepository_StoreDelete_ReturnStoreIsEmpty(){
        Set<Product> products = new HashSet<>();
        Store store = new Store(1, "Supermarket", "blablabla", 5, products,new Address());

        storeRepository.save(store);

        storeRepository.deleteById(store.getId());

        Optional<Store> storeReturn = storeRepository.findById(store.getId());

        Assertions.assertTrue(storeReturn.isEmpty());
    }



}
