package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.converter.ProductConverter;
import com.aca.acaonlinestore.entity.*;
import com.aca.acaonlinestore.model.ProductDTO;
import com.aca.acaonlinestore.model.ProductRatingDTO;
import com.aca.acaonlinestore.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import javax.swing.text.html.Option;

import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@ExtendWith(SpringExtension.class)
@WebMvcTest(ProductRestController.class)
@AutoConfigureMockMvc(addFilters = false)
public class ProductControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;

    @MockBean
    private ProductConverter productConverter;

    private ProductDTO productDto;
    private ProductDTO updatedProductDTO;
    private Product product;
    private Store store;
    private Category category;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup(){
        category = new Category(2L,"Category for repo","description for category",new ArrayList<Product>());
        store = new Store(1L,"Store for repo","description for store",4,new HashSet<>(), new Address());
        productDto = new ProductDTO(2L,"Product 1", "some description",50.5,10,5,12.1,7L,category.getId(),category.getName());
        updatedProductDTO = new ProductDTO(2L,"newName", "New Product Description",99.99,9,5,12.1,7L,category.getId(),category.getName());
        product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,store,category, new ArrayList<ProductRating>());
    }
    @Test
    public void testCreateProduct() throws Exception{
        when(productService.createProduct(productDto)).thenReturn(productDto);
        mockMvc.perform(post("/products/create").content(objectMapper.writeValueAsString(productDto)).contentType(MediaType.APPLICATION_JSON))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.name").value("Product 1"))
                .andExpect(jsonPath("$.id").value(2L))
                .andExpect(jsonPath("$").isNotEmpty());
        verify(productService, times(1)).createProduct(productDto);

    }
    @Test
    public void getProductById() throws Exception{
        when(productService.getProductById(productDto.getId())).thenReturn(product);
        mockMvc.perform(get("/products/2").content(objectMapper.writeValueAsString(productDto.getId())).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(product.getId()))
                .andExpect(jsonPath("$.name").value("Product 1"))
                .andExpect(jsonPath("$.description").value("some description"))
                .andExpect(jsonPath("$.price").value(50.5))
                .andExpect(jsonPath("$.availability").value(10))
                .andExpect(jsonPath("$.averageRate").value(5))
                .andExpect(jsonPath("$.category").isNotEmpty());

    }
    @Test
    public void getAllProducts() throws Exception{
        when(productService.getAllProducts()).thenReturn(Collections.singletonList(productDto));
        mockMvc.perform(get("/products")).andDo(print())
                .andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$").isArray());

    }
    @Test
    public void testDeleteProduct() throws Exception{
        when(productService.deleteProduct(product.getId())).thenReturn(true);
        mockMvc.perform(delete("/products/{product_id}", product.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }

    @Test
    public void testDecreaseProductAvailability() throws Exception{
        when(productService.decreaseProductAvailability(2L)).thenReturn(updatedProductDTO);
        mockMvc.perform(put("/products/2/decreaseAvailability", product.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(2L))
                .andExpect(jsonPath("$.availability").value(9));

    }

    @Test
    public void testUpdateProductName() throws Exception{

        when(productService.updateProductName("newName", 2L)).thenReturn(updatedProductDTO);
        mockMvc.perform(put("/products/2/updateProductName").param("name", "newName").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(product.getId()))
                .andExpect(jsonPath("$.name").value(updatedProductDTO.getName()));
    }

    @Test
    public void testUpdateProductDescription() throws Exception{
        String newDescription = "New Product Description";

        when(productService.updateProductDescription(newDescription, product.getId())).thenReturn(updatedProductDTO);
        mockMvc.perform(put("/products/2/updateProductDescription").param("description", newDescription)
                        .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).
                andExpect(content().contentType(MediaType.APPLICATION_JSON)).
                andExpect(jsonPath("$.id").value(product.getId())).
                andExpect(jsonPath("$.description").value(updatedProductDTO.getDescription()));

    }

    @Test
    public void testUpdateProductPrice() throws Exception{
        double newPrice = 99.99;
        when(productService.updateProductPrice(newPrice, 2L)).thenReturn(updatedProductDTO);
        mockMvc.perform(put("/products/2/updateProductPrice").param("price", String.valueOf(newPrice))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(2))
                .andExpect(jsonPath("$.price").value(updatedProductDTO.getPrice()));

    }
}
