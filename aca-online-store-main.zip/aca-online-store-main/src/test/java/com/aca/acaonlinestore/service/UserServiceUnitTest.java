package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.AddressConverter;
import com.aca.acaonlinestore.converter.UserConverter;
import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.Cart;
import com.aca.acaonlinestore.entity.User;
import com.aca.acaonlinestore.exception.UserNotFoundException;
import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.UserDTO;
import com.aca.acaonlinestore.repository.AddressRepository;
import com.aca.acaonlinestore.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
public class UserServiceUnitTest {
    @Mock
    UserRepository userRepository;

    @Mock
    AddressRepository addressRepository;
    @Mock
    UserConverter userConverter;
    @Mock
    AddressConverter addressConverter;

    @InjectMocks
    UserService userService;

    private User user;
    private User user2;
    private UserDTO userDTO;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setUsername("testuser");
        user.setEmail("mail@mail.ru");
        user.setPassword("pass");
        user.setPhoneNumber("12432");
        user.setCart(new Cart());
        user.setRole(User.Role.ROLE_USER);

        user2 = new User();
        user2.setUsername("testuser");
        user2.setEmail("mail@mail.ru");
        user2.setPassword("pass");
        user2.setPhoneNumber("12432");

        userDTO = new UserDTO("testuser", "mail@mail.ru", "pass", "12432");
    }

    @Test
    public void testSaveUser() {
        when(userConverter.convertToEntity(eq(userDTO), any(User.class))).thenReturn(user);
        when(userRepository.save(any(User.class))).thenReturn(user);

        User saveUser = userService.saveUser(userDTO, "pass", User.Role.ROLE_USER);
        verify(userConverter, times(1)).convertToEntity(eq(userDTO), any(User.class));
        verify(userRepository).save(any(User.class));

        assertNotNull(saveUser);
        assertEquals("mail@mail.ru", saveUser.getEmail());
        assertEquals("testuser", saveUser.getUsername());
    }

    @Test
    public void testUserExists() {
        userRepository.save(user2);

        when(userRepository.existsByUsername(user2.getUsername())).thenReturn(true);
        when(userRepository.existsByEmail(user2.getEmail())).thenReturn(true);

        Boolean userExists = userService.userExists("testuser", "mail@mail.ru");

        assertNotEquals(userExists, null);
        assertTrue(userExists);

    }

    @Test
    public void testGetUserByEmail_Found() {
        User mockUser = new User();
        String email = "test@mail.ru";

        when(userRepository.findByEmail(email)).thenReturn(Optional.of(mockUser));

        User user1 = userService.getUserByEmail(email);
        assertEquals(user1, mockUser);
    }

    @Test
    public void testGetUserByEmail_ThrowsException(){
        String email = "some@mail.ru";

        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, ()-> userService.getUserByEmail(email));
    }

    @Test
    public void getAddressById() {
        Address address1 = new Address();
        address1.setId(11L);
        address1.setCountry("armenia");
        User user1 = new User();
        List<Address> addressList = new ArrayList<>();
        addressList.add(address1);
        user1.setDeliverAddress(addressList);

        String email = "some@mail.ru";

        when(userRepository.findByEmail(email)).thenReturn(Optional.of(user1));
        when(addressRepository.findById(11L)).thenReturn(Optional.of(address1));

        Address addressById = userService.getAddressById(email, 11L);
        assertNotNull(addressById);
        assertEquals(address1.getCountry(), "armenia");
    }

    @Test
    public void testAddAddress() {
        AddressDTO addressDTO1 = new AddressDTO(10L, "evn", "arm", "komitas", "0012");
        Address address1 = new Address();
        address1.setStreet("komitas");
        address1.setCity("evn");
        address1.setCountry("arm");
        address1.setPostalCode("0012");
        address1.setId(10L);

        User user1 = new User();
        user1.setId(1L);
        user1.setEmail("email@email");

        when(userRepository.save(any(User.class))).thenReturn(user1);
        when(userRepository.findByEmail("email@email")).thenReturn(Optional.of(user1));
        when(addressConverter.convertToEntity(any(AddressDTO.class), any(Address.class))).thenReturn(address1);
        when(addressRepository.save(any(Address.class))).thenReturn(address1);

        User user3 = userService.addAddress(user1.getEmail(), addressDTO1);

        verify(userRepository, times(1)).save(user1);
        verify(addressRepository, times(1)).save(address1);
        verify(addressConverter, times(1)).convertToEntity(eq(addressDTO1), any(Address.class));

        assertNotNull(user3);
        assertEquals(address1.getUser().getEmail(), "email@email");
    }
}
