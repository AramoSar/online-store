package com.aca.acaonlinestore.service;


import com.aca.acaonlinestore.converter.CategoryConverter;
import com.aca.acaonlinestore.entity.Category;
import com.aca.acaonlinestore.model.CategoryDTO;
import com.aca.acaonlinestore.repository.CategoryRepository;
import com.aca.acaonlinestore.service.CategoriesService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.security.cert.Extension;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;
import static org.springframework.test.util.AssertionErrors.assertEquals;

@ExtendWith(SpringExtension.class)
public class CategoryServiceUnitTest {
    @Mock
    CategoryRepository categoriesRepository;
    @Mock
    CategoryConverter categoryConverter;
    @InjectMocks
    CategoriesService categoriesService;
    private Extension category;


    @Test
    public void testCreateCategory() {
        Category category = new Category(12, "mobile", "description");
        categoriesService.save(categoryConverter.convertToModel(category,new CategoryDTO()));
        verify(categoriesRepository, times(1)).save(category);
        ArgumentCaptor<Category> orderArgumentCaptor = ArgumentCaptor.forClass(Category.class);
        verify(categoriesRepository).save(orderArgumentCaptor.capture());
        Category categoryCreated = orderArgumentCaptor.getValue();
        assertNotNull(categoryCreated.getId());
        assertEquals("","mobile", categoryCreated.getName());
    }

    @Test
    public void testDeleteCategory() {
        Category order = new Category(13L, "mobile", "description");
        when(categoriesRepository.findById(13L)).thenReturn(Optional.of(order));
        categoriesService.getCategoryById((long) Integer.parseInt(category.getId()));
        verify(categoriesRepository, times(1)).deleteById(Long.valueOf(Integer.valueOf(category.getId())));
        ArgumentCaptor<Long> categoryArgumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(categoriesRepository).deleteById((long) Math.toIntExact(categoryArgumentCaptor.capture()));
        Long orderIdDeleted = categoryArgumentCaptor.getValue();
        assertNotNull(orderIdDeleted);
        assertEquals("", "TV", orderIdDeleted);
    }
}

