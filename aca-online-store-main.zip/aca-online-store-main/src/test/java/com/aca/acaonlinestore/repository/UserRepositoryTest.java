package com.aca.acaonlinestore.repository;

import com.aca.acaonlinestore.entity.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@ExtendWith(SpringExtension.class)
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class UserRepositoryTest {
    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    public void setUp() {
        User user = new User();
        user.setUsername("username1");
        user.setEmail("user@mail.ru");
        user.setPhoneNumber("124143");
        user.setPassword("asjfewjfb");
        userRepository.save(user);
    }

    @AfterEach
    public void destroy() {
        userRepository.deleteAll();
    }

    @Test
    public void testFindByUsernameOrEmail() {
        String username = "username1";
        String email = "user@mail.ru";
        User byUsernameOrEmail = userRepository.findByEmail(email).get();

        assertThat(byUsernameOrEmail.getUsername()).isEqualTo(username);
        assertThat(byUsernameOrEmail.getEmail()).isEqualTo(email);
        assertThat(byUsernameOrEmail.getPhoneNumber()).isEqualTo("124143");
        assertThat(byUsernameOrEmail.getPassword()).isEqualTo("asjfewjfb");
    }
}
