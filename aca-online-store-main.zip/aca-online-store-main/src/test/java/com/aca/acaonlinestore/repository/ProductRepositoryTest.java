package com.aca.acaonlinestore.repository;

import com.aca.acaonlinestore.entity.*;
import org.hibernate.validator.internal.util.Contracts;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ExtendWith(SpringExtension.class)
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
public class ProductRepositoryTest {
    @Autowired
    ProductRepository productRepository;

    @Autowired
    StoreRepository storeRepository;

    @Autowired
    CategoryRepository categoryRepository;

    private Store store;
    private Store store1;
    private Category category;
    private Category category1;
    @BeforeEach
    public void setUp(){
        storeRepository.save(new Store(1L,"Store for repo","description for store",4,new HashSet<>(),new Address()));
        productRepository.save(new Product(5L,"Product for repo","description for the test",72.6,2,1,12.1,store,category,new ArrayList<ProductRating>()));
        productRepository.save(new Product(9L,"Another product for repo","description for the test",72.7,3,4,5,store,category,new ArrayList<ProductRating>()));
        categoryRepository.save(new Category(2L,"Category for repo","description for category",new ArrayList<Product>()));
    }
    @AfterEach
    public void destroy(){
        productRepository.deleteAll();
        storeRepository.deleteAll();
        categoryRepository.deleteAll();
    }
    @Test
    public void testCreateProduct(){
        Product saved  = new Product(5L,"Product for repo","description for the test",72.6,2,1,2,store,category,new ArrayList<ProductRating>());
        Store storeSaved = new Store(1L,"Store for repo","description for store",4,new HashSet<>(),new Address());
        Category categorySaved = new Category(2L,"Category for repo","description for category",new ArrayList<Product>());
        Store storeReturned = storeRepository.save(storeSaved);
        Category categoryReturned = categoryRepository.save(categorySaved);
        Product returned = productRepository.save(saved);
        Contracts.assertNotNull(returned);
        Contracts.assertNotNull(returned.getName());
        Assertions.assertTrue(returned.getId() >= 0);
        Assertions.assertEquals(saved.getName(), returned.getName());
    }
    @Test
    public void testGetProductById(){
        Product saved  = new Product(5L,"Product for repo","description for the test",72.6,2,1,3,store,category,new ArrayList<ProductRating>());
        Store storeSaved = new Store(1L,"Store for repo","description for store",4,new HashSet<>(),new Address());
        Category categorySaved = new Category(2L,"Category for repo","description for category",new ArrayList<Product>());
        Store storeReturned = storeRepository.save(storeSaved);
        Category categoryReturned = categoryRepository.save(categorySaved);
        Product returned = productRepository.save(saved);
        Optional<Product> product = productRepository.findById(returned.getId());
        assertTrue(product.isPresent());
        Product receivedProduct = product.get();
        assertNotNull(receivedProduct);
    }
    @Test
    public void testGetAllProducts(){

        Product product  = new Product(5L,"Product for repo","description for the test",72.6,2,1,12.1,store,category,new ArrayList<ProductRating>());
        Product product1 = new Product(5L,"Product for repo","description for the test",72.6,2,1,12.1,store,category,new ArrayList<ProductRating>());
        //Store store = new Store(1L,"Store for repo","description for store",4,new HashSet<>(), new Address());
        //Category category = new Category(2L,"Category for repo","description for category",new ArrayList<Product>());
        //Category category1 = new Category(4L,"Category for repo","description for category",new ArrayList<Product>());

        productRepository.save(product);
        productRepository.save(product1);

        List<Product> products = productRepository.findAll();
        assertNotNull(products);
        Assertions.assertTrue(products.get(0).getId() >= 0);
        Assertions.assertEquals(4, products.size());
        Assertions.assertEquals("Product for repo", products.get(0).getName());
    }
    @Test
    public void testDeleteProduct(){
        Product saved = new Product(5L,"Product for repo","description for the test",72.6,2,1,10,store,category,new ArrayList<ProductRating>());
        //Store storeSaved = new Store(1L,"Store for repo","description for store",4,new HashSet<>(),new Address());
        //Category categorySaved = new Category(2L,"Category for repo","description for category",new ArrayList<Product>());
        //Store storeReturned = storeRepository.save(storeSaved);
       // Category categoryReturned = categoryRepository.save(categorySaved);
        productRepository.save(saved);
        productRepository.deleteById(saved.getId());
    }
}
