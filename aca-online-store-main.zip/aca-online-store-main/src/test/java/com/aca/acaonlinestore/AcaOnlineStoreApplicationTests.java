package com.aca.acaonlinestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcaOnlineStoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
