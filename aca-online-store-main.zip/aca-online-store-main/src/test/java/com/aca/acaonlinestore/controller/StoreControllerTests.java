package com.aca.acaonlinestore.controller;

import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.StoreDTO;
import com.aca.acaonlinestore.model.UserDTO;
import com.aca.acaonlinestore.service.StoreService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(StoreController.class)
@AutoConfigureMockMvc(addFilters = false)
public class StoreControllerTests {

    @MockBean
    StoreService storeService;

    @Autowired
    MockMvc mockMvc;

    @Test
    public void storeController_registerStore_returnStoreDto() throws Exception {
        StoreDTO storeDto = new StoreDTO(1, "Supermarket", "blablabla",new AddressDTO(), 5);

        when(storeService.registerStore(Mockito.any(StoreDTO.class),Mockito.any(UserDTO.class))).thenReturn(storeDto);

        String jsonRequest = new ObjectMapper().writeValueAsString(storeDto);
        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/store/register").contentType(MediaType.APPLICATION_JSON).content(jsonRequest))
                .andExpect(status().isOk());

        String jsonResponse = resultActions.andReturn().getResponse().getContentAsString();
        System.out.println("Response JSON: " + jsonResponse);

    }

    @Test
    public void storeController_GetStoreList_ReturnStoreList() throws Exception {
        List<StoreDTO> storeList = Arrays.asList(new StoreDTO(1, "Supermarket", "blablabla",new AddressDTO(), 5),
        new StoreDTO(2, "Yerevan City", "blablabla",new AddressDTO(), 5));

        when(storeService.getAllStores()).thenReturn(storeList);

        ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.get("/store/list").contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void storeController_GetStoreById_ReturnStore() throws Exception {
        StoreDTO storeDto = new StoreDTO(1, "Supermarket", "blablabla", new AddressDTO(), 5);

        when(storeService.getStoreById(1)).thenReturn(storeDto);
        String jsonRequest = new ObjectMapper().writeValueAsString(storeDto);
        mockMvc.perform(MockMvcRequestBuilders.get("/store/{storeId}",1).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Supermarket"));
    }

    @Test
    public void storeController_DeleteStore_ReturnEmptyStore() throws Exception {
        StoreDTO storeDto = new StoreDTO(1, "Supermarket", "blablabla", new AddressDTO(), 5);
        doNothing().when(storeService).deleteStoreById(1,1);
        String jsonRequest = new ObjectMapper().writeValueAsString(storeDto);
        mockMvc.perform(MockMvcRequestBuilders
                        .delete("/{adminId}/{storeId}",1L,1L)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(jsonRequest))
                        .andReturn();
    }

    @Test
    public void storeController_UpdateStore_ReturnUpdatedStoreDto() throws Exception {

        StoreDTO storeDto = new StoreDTO(1, "Supermarket", "blablabla",new AddressDTO(), 5);

        when(storeService.updateStore(1, storeDto)).thenReturn(storeDto);

        String jsonRequest = new ObjectMapper().writeValueAsString(storeDto);
        mockMvc.perform(MockMvcRequestBuilders.put("/store/admin/update/{storeId}",1)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonRequest)).andExpect(status().isOk());
    }
}
