package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.StoreConverter;
import com.aca.acaonlinestore.entity.Address;
import com.aca.acaonlinestore.entity.Product;
import com.aca.acaonlinestore.entity.Store;
import com.aca.acaonlinestore.model.AddressDTO;
import com.aca.acaonlinestore.model.StoreDTO;
import com.aca.acaonlinestore.model.UserDTO;
import com.aca.acaonlinestore.repository.StoreRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class StoreServiceUnitTest {
    @Mock
    UserService userService;
    @Mock
    private StoreRepository storeRepository;
    @Mock
    private StoreConverter storeConverter;
    @Mock
    private PasswordEncoder passwordEncoder;
    @InjectMocks
    private StoreService storeService;

    @Test
    public void storeService_RegisterStore_ReturnStoreDto() {
        Store store = new Store(1, "Supermarket", "blablabla", 5, new HashSet<Product>(),new Address());

        StoreDTO storeDto = new StoreDTO(1, "Supermarket", "blablabla", new AddressDTO(),5);

        UserDTO userDto = new UserDTO();
        when(storeConverter.convertToEntity(Mockito.any(StoreDTO.class), Mockito.any(Store.class))).thenReturn(store);
        when(storeConverter.convertToModel(Mockito.any(Store.class), Mockito.any(StoreDTO.class))).thenReturn(storeDto);
        when(passwordEncoder.encode(userDto.getPassword())).thenReturn(String.valueOf(userDto));
        when(storeRepository.save(Mockito.any(Store.class))).thenReturn(store);

        StoreDTO savedStore = storeService.registerStore(storeDto,userDto);

        Assertions.assertThat(savedStore).isNotNull();

        //todo test faila anum, user nullpointera qcum, ASK DAVID
    }

    @Test
    public void storeService_GetAllStores_ReturnStoreList(){
        List<Store> storeList = new ArrayList<>();
        Store store = new Store(1, "Supermarket", "blablabla", 5, new HashSet<Product>(),new Address());

        Store store1 = new Store(2, "Supermarket", "blablabla", 5, new HashSet<Product>(),new Address());
        storeList.add(store);
        storeList.add(store1);


        StoreDTO storeDTO1 = new StoreDTO(1, "Supermarket", "blablabla",new AddressDTO(), 5);
        StoreDTO storeDTO2 = new StoreDTO(2, "Supermarket", "blablabla", new AddressDTO(), 5);

        when(storeConverter.convertToModel(storeList.get(0),new StoreDTO())).thenReturn(storeDTO1);
        when(storeConverter.convertToModel(storeList.get(1),new StoreDTO())).thenReturn(storeDTO2);
        when(storeRepository.findAll()).thenReturn(storeList);

        List<StoreDTO> result = storeService.getAllStores();
        assertEquals(2,result.size());
        assertEquals(storeDTO1,result.get(0));
        assertEquals(storeDTO2,result.get(1));
    }

    @Test
    public void storeService_GetStoreById_ReturnStore() {
        Store store = new Store(1, "Supermarket", "blablabla", 5, new HashSet<Product>(), new Address());

        StoreDTO storeDto = new StoreDTO();

        when(storeRepository.findById(1L)).thenReturn(Optional.of(store));
        when(storeConverter.convertToModel(Mockito.eq(store), any(StoreDTO.class))).thenReturn(storeDto);

        StoreDTO retrievedStore = storeService.getStoreById(1);
        Assertions.assertThat(retrievedStore).isNotNull();

    }

    @Test
    public void storeService_UpdateStore_ReturnsStoreDto() {
        Store store = new Store(1, "Supermarket", "blablabla", 5, new HashSet<Product>(), new Address());

        StoreDTO storeDto = new StoreDTO(1, "Supermarket", "blablabla",new AddressDTO(), 5);
        when(storeRepository.findById(1L)).thenReturn(Optional.of(store));
        when(storeConverter.convertToModel(Mockito.any(Store.class), Mockito.any(StoreDTO.class))).thenReturn(storeDto);
        when(storeRepository.save(Mockito.any(Store.class))).thenReturn(store);

        StoreDTO savedStoreDTO = storeService.updateStore(1, storeDto);


        Assertions.assertThat(savedStoreDTO).isNotNull();
    }

    @Test
    public void storeService_DeleteById_ReturnsEmptyStore() {
        Store store = new Store(1, "Supermarket", "blablabla", 5, new HashSet<Product>(), new Address());

        assertAll(() -> storeService.deleteStoreById(1,1));
    }
}




