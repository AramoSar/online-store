package com.aca.acaonlinestore.service;

import com.aca.acaonlinestore.converter.ProductConverter;
import com.aca.acaonlinestore.entity.*;
import com.aca.acaonlinestore.exception.ProductNotFoundException;
import com.aca.acaonlinestore.model.ProductDTO;
import com.aca.acaonlinestore.model.ProductRatingDTO;
import com.aca.acaonlinestore.repository.CategoryRepository;
import com.aca.acaonlinestore.repository.ProductRepository;
import com.aca.acaonlinestore.repository.StoreRepository;
import org.hibernate.validator.internal.util.Contracts;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

    @InjectMocks
    ProductService productService;

    @Mock
    ProductRepository productRepository;

    @Mock
    private StoreRepository storeRepository;
    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    ProductConverter converter;
    @Mock
    UserService userService;

    @BeforeEach
    public void init(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateProduct(){
        Product product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        ProductDTO productDto = new ProductDTO(2L,"Product 1", "some description",50.5,10,5,12.1,4L,new Category().getId(), new Category().getName());
        when(productRepository.save(product)).thenReturn(product);
        when(converter.convertToEntity(eq(productDto),any(Product.class))).thenReturn(product);
        when(converter.convertToModel(product, productDto)).thenReturn(productDto);
        productService.createProduct(productDto);

        ArgumentCaptor<Product> argumentCaptor = ArgumentCaptor.forClass(Product.class);
        verify(productRepository).save(argumentCaptor.capture());
        Product productCreated = argumentCaptor.getValue();
        Contracts.assertNotNull(productCreated.getId());
        assertEquals("Product 1",productCreated.getName());
        assertEquals("some description",productCreated.getDescription());
    }
    @Test
    public void testGetProductById() throws ProductNotFoundException {
        Product product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        ProductDTO productDto = new ProductDTO();
        when(productRepository.findById(2L)).thenReturn(Optional.of(product));
        when(converter.convertToModel(product, productDto)).thenReturn(productDto);
        ProductDTO productById = converter.convertToModel(productService.getProductById(2L),productDto);
        Contracts.assertNotNull(productById,null);

    }
    @Test
    public void testGetAllProducts(){
        Product product1 = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        Product product2 = new Product(4L,"Product 2", "some description",50.7,8,4,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        User user = new User(1L,"username","email@com","password","02222", User.Role.ROLE_STORE_ADMIN,new Store(),new ArrayList<Address>(),new Cart(),new ArrayList<Order>());
        when(productRepository.findAll()).thenReturn(Arrays.asList(product1,product2));
        UserDetails authUserPrincipal = userService.getAuthUserPrincipal();
        String username = authUserPrincipal.getUsername();

        List<ProductDTO> products = productService.getAllProducts();
        assertEquals(products.size(),2);
        assertEquals(product1.getName(),"Product 1");
        assertEquals(product2.getName(),"Product 2");
    }
    @Test
    public void testDeleteProduct(){
        Product product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        boolean result = productService.deleteProduct(product.getId());
        verify(productRepository,times(1)).deleteById(product.getId());
        ArgumentCaptor<Long> argumentCaptor = ArgumentCaptor.forClass(Long.class);
        verify(productRepository).deleteById(argumentCaptor.capture());
        Long deletedProductId = argumentCaptor.getValue();
        Contracts.assertNotNull(deletedProductId);
        assertEquals(2L,deletedProductId);
        assertTrue(result);
    }

    @Test
    public void testDecreaseProductAvailability(){
        Product product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        ProductDTO productDto = new ProductDTO();

        when(productRepository.findById(2L)).thenReturn(Optional.of(product));
        when(converter.convertToModel(product, productDto)).thenReturn(productDto);
        try {
            productService.decreaseProductAvailability(product.getId());
        } catch (ProductNotFoundException e) {
            e.printStackTrace();
        }
        ArgumentCaptor<Product> argumentCaptor = ArgumentCaptor.forClass(Product.class);
        verify(productRepository).save(argumentCaptor.capture());
        Product productCreated = argumentCaptor.getValue();
        converter.convertToModel(productCreated,productDto);
        Contracts.assertNotNull(productCreated.getId());
        assertEquals(9,productCreated.getAvailability());
    }


    @Test
    public void testUpdateProductName() throws ProductNotFoundException {

        Product product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        ProductDTO productDto = new ProductDTO(2L,"new name", "some description",50.5,10,5,12.1,6L,1L,"category");
        when(productRepository.findById(2L)).thenReturn(Optional.of(product));
        //check with Argument Captor
        when(converter.convertToModel(Mockito.any(Product.class),Mockito.any(ProductDTO.class))).thenReturn(productDto);
        when(productRepository.save(Mockito.any(Product.class))).thenReturn(product);
        ProductDTO savedProductDTO = productService.updateProductName("new name",2L);
        Contracts.assertNotNull(savedProductDTO.getId());
        assertEquals("new name", savedProductDTO.getName());
    }

    @Test
    public void testUpdateProductDescription(){
        Product product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        ProductDTO productDto = new ProductDTO(2L,"new description", "some description",50.5,10,5,12.1,6L,1L,"category");
        when(productRepository.findById(2L)).thenReturn(Optional.of(product));
        try {
            productService.updateProductDescription("new description",product.getId());
        } catch (ProductNotFoundException e) {
            e.printStackTrace();
        }
        verify(productRepository,times(1)).save(product);
        ArgumentCaptor<Product> argumentCaptor = ArgumentCaptor.forClass(Product.class);
        verify(productRepository).save(argumentCaptor.capture());
        Product productCreated = argumentCaptor.getValue();
        Contracts.assertNotNull(productCreated.getId());
        assertEquals("new description",productCreated.getDescription());
    }
    @Test
    public void testUpdateProductPrice(){
        Product product = new Product(2L,"Product 1", "some description",50.5,10,5,12.1,new Store(),new Category(), new ArrayList<ProductRating>());
        when(productRepository.findById(2L)).thenReturn(Optional.of(product));
        try {
            productService.updateProductPrice(40.1,product.getId());
        } catch (ProductNotFoundException e) {
            e.printStackTrace();
        }
        verify(productRepository,times(1)).save(product);
        ArgumentCaptor<Product> argumentCaptor = ArgumentCaptor.forClass(Product.class);
        verify(productRepository).save(argumentCaptor.capture());
        Product productCreated = argumentCaptor.getValue();
        Contracts.assertNotNull(productCreated.getId());
        assertEquals(40.1,productCreated.getPrice());
    }




}
